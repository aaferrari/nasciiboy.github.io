// Listado: Item.cpp
// Implementación de la clase Item
#include <iostream>
#include <SDL/SDL.h>

#include "Item.h"
#include "Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Item::Item( enum tipo_participantes tpo, Juego *juego, int x, int y, int direccion ):
  Participante( juego, x, y, direccion ) {
  tipo = tpo;

  // imagen según el tpo de item creado
  if( tpo == TIPO_ITEM_POWER ){
    imagen = juego->universo->galeria->get_imagen( Galeria::ITEM_POWER );

    // animaciones de los estado de los objetos
    animaciones[ PARADO ] = new Secuencia( "0,0,1,2,1", 10 );
    animaciones[ MORIR ] = new Secuencia( "3,4", 10 );

    SDL_Rect rect_principal = { 41, 85, 13, 11 };
    add_rect(rect_principal);
  } else if( tpo == TIPO_ITEM_LIFE ){
    imagen = juego->universo->galeria->get_imagen( Galeria::ITEM_LIFE );

    // animaciones de los estado de los objetos
    animaciones[ PARADO ] = new Secuencia( "0,0,1,2,3,4,5,6,7,6,5,4,3,2,1", 10 );
    animaciones[ MORIR ] = new Secuencia( "8,9", 10 );

    SDL_Rect rect_principal = { 44, 80, 11, 16 };
    add_rect( rect_principal );
  } else
    cerr << "Item::Item(): Caso no contemplado" << endl;

  estado = PARADO;

#ifdef DEBUG
  cout << "Item::Item()" << endl;
#endif
}

Item::~Item(){
  map<estados, Secuencia *>::iterator p = animaciones.begin();
  while ( p != animaciones.end() ){
    delete p->second;
#ifdef DEBUG
    cout << "Item delete estado: " << p->first << endl;
#endif
    p++;
  }

#ifdef DEBUG
  cout << "Item::~Item()" << endl;
#endif
}

void Item::actualizar(){
  // si el item "muere" lo marcamos para eliminar si no avanzamos la animación
  if( estado == MORIR ){
    if( animaciones[ estado ]->avanzar() )
      estado = ELIMINAR;
  }
  else if( estado == ELIMINAR );
  else
    animaciones[estado]->avanzar();

  // si llega al limite vertical muere
  if( y > NIV_HEIGHT ){ estado = ELIMINAR; }

  /* Por si está colocado en las alturas y tiene que caer en alguna superficie
     necesita una velocidad de caida */
  velocidad_salto += 0.1;
  y += altura( (int)velocidad_salto );
}

void Item::colisiona_con( Participante *otro ){
  // si colisiona, muere para desaparecer
  if( estado != MORIR ){
    juego->universo->galeria->sonidos[ Galeria::COGE_ITEM ]->reproducir();

    estado = MORIR;
  }
}

int Item::pv_life(){ return animaciones[ estado ]->get_frame(); }
