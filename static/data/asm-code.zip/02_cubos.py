suma = 0
for num in range(1, 11):
    cubo = num * num * num
    suma = suma + cubo

print("El resultado es: {}".format(suma))
print("El resultado en hexadecimal es: 0x{:08X}".format(suma))
