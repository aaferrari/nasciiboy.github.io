// Listado: Item.h
// Esta clase controla todo lo relativo a los items u objetos del juego
#ifndef ITEM_H
#define ITEM_H

#include "Participante.h"

class Item: public Participante {
 public:
  Item( enum tipo_participantes tipo, Juego *juego, int x,
	int y, int direccion = 1 );
  virtual ~Item();

  void actualizar();
  void colisiona_con( Participante *otro );
  int pv_life();
};

#endif
