// Listado: Intro.cpp
// Implementación de la clase Intro
#include <iostream>

#include "Intro.h"
#include "Universo.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Sonido.h"
#include "Teclado.h"
#include "Fuente.h" 
#include "Texto.h"
#include "Musica.h"
#include "Control_Movimiento.h"

using namespace std;

Intro::Intro( Universo *universo ) : Interfaz( universo ) {
  // el dispositivo de entrada nos lo da el entorno del juego
  teclado = &( universo->teclado );
  
  IN_BG_COLOR = SDL_MapRGB( universo->pantalla->format, 255, 255, 255 );
  get_titulo();     // creamos los títulos
  reiniciar();      // inicio el Intro
  get_strings();

#ifdef DEBUG
  cout << "Intro::Intro()" << endl;
#endif
}

Intro::~Intro(){
  // liberamos memoria
  delete gnu;
  delete sdl;
  delete i;

#ifdef DEBUG
  cout << "Intro::~Intro()" << endl;
#endif
}

void Intro::get_titulo(){
  // creamos los títulos animados
  gnu = 
    new Control_Movimiento( universo->galeria->get_imagen( Galeria::INTRO_GNU ), \
			    0, 0, 0, 3 );
  sdl = 
    new Control_Movimiento( universo->galeria->get_imagen( Galeria::INTRO_SDL ), \
			    0, 0, 0, 3 );
  i = 
    new Control_Movimiento( universo->galeria->get_imagen( Galeria::INTRO_I ), \
			    0, 0, 0, 3 );
}

void Intro::get_strings(){
  // crea las cadenas que mostraremos como opciones
  char textos[][ 40 ] = { { "(test)videogame" },
			  { "c r e a t e d  w h i t h :" } };

  // cargamos la fuente
  Fuente *fuente = universo->galeria->get_fuente( Galeria::FUENTE_MENU );

  end_chars[ 0 ] = new Texto( fuente, 200, 10, textos[ 0 ] );
  end_chars[ 1 ] = new Texto( fuente, 80, 50, textos[ 1 ] );
}

void Intro::reiniciar(){
  // hacemos sonar la música
  universo->galeria->get_musica( Galeria::MUSICA_MENU )->pausar();   
  //  universo->galeria->get_musica( Galeria::MUSICA_MENU )->reproducir();

  /* colocamos cada parte del título en su lugar desde una posición 
     de origen hasta la posición final */
  gnu->mover_inmediatamente( 700, 480 );
  gnu->mover( 10, 120 );
  sdl->mover_inmediatamente( -200, 480 );
  sdl->mover( 450, 210 );
  i->mover_inmediatamente( 500, 480 );
  i->mover( 350, 230 );

  delay = 900;
}

void Intro::actualizar(){
  // actualizamos los títulos
  gnu->actualizar();
  if( sdl->actualizar() ) // cuando llega a su posicion se actualiza la '&'
    i->actualizar();

  if( teclado->pulso( OK ) || delay == 0 )
    universo->set_interfaz( ESCENA_MENU );

  if( delay ) delay--; // reducimos el retardo
}

void Intro::dibujar(){
  static SDL_Color color = { 0, 0, 0, 255 };

  // dibujamos el fondo con el color anaranjado
  SDL_FillRect( universo->pantalla, NULL, IN_BG_COLOR );

  // dibujamos los títulos
  gnu->dibujar( universo->pantalla );
  sdl->dibujar( universo->pantalla );
  i->dibujar( universo->pantalla );

  // dibujamos las 3 cadenas de opciones
  for( int i = 0; i < NUM_S; i ++ )
    end_chars[ i ]->dibujar( universo->pantalla, color );

  // actualizamos la pantalla del entorno
  SDL_Flip( universo->pantalla );
}
