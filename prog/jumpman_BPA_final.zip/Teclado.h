// Listado: Teclado.h
// Control de dispositivo de entrada
#ifndef _TECLADO_H
#define _TECLADO_H

#include <SDL/SDL.h>
#include <map>

using namespace std;

class Teclado {
 public:
  Teclado();                        // constructor
  ~Teclado();                       // destructor

  void actualizar();                // actualiza la informacion del teclado
  bool pulso( const SDLKey key );   // informa si una tecla ha sido pulsada

 private:
  // para conocer el estado de la pulsacion de las teclas en todo momento
  Uint8 *teclas;
};

#endif
