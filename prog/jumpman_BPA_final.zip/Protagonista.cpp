// Listado: Protagonista
// Implementación de la clase Protagonista
#include <iostream>

#include "Protagonista.h"
#include "Juego.h"
#include "Teclado.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Universo.h"
#include "Nivel.h"
#include "Imagen.h"
#include "Secuencia.h"

using namespace std;

Protagonista::Protagonista( Juego *juego, int x, int y, int direccion )
  : Participante( juego, x, y, direccion ) {
  // inicializamos los atributos de la clase
  this->teclado = &( juego->universo->teclado );
  set_pv( HERO_PV );
  x0 = x;
  y0 = y;
  super = 180; // ciclos de invulnerable

  imagen = juego->universo->galeria->get_imagen( Galeria::HERO );

  /* asociamos al personaje las animaciones
     según la rejilla que cargamos para controlarlo */
  animaciones[ APPEAR ] = new Secuencia( "35,35,36", 0 );
  animaciones[ PARADO ] = new Secuencia( "0", 4 );
  animaciones[ CAMINAR ] = new Secuencia( "1,2,3,4,5,6,7,8,9,10", 5 );
  animaciones[ SALTAR ] = new Secuencia( "11,12,13,14,15,16", 0 );
  animaciones[ GOLPEAR ] = new Secuencia( "22,23,24,25,26", 10 );
  animaciones[ SUPER ] = new Secuencia( "33,34,35,36,37,38,39,40,41,42", 7 );
  animaciones[ MORIR ] = 
    new Secuencia( "44,45,46,47,48,48,55,56,57,58,59,60,61,62,63,64,65 ", 4 );
  animaciones[ DAMAGE ] = new Secuencia( "44,45,46,47,48,49,50,51,52,53", 7 );

  reiniciar();


  SDL_Rect rect_principal[] = { { 25, 20, 50, 80 } };
  for( int i = 0; i < 1; i++ )
    add_rect(rect_principal[ i ] );

#ifdef DEBUG
  cout << "Protagonista::Protagonista()" << endl;
#endif
}

Protagonista::~Protagonista(){
  map<estados, Secuencia *>::iterator p = animaciones.begin();
  while ( p != animaciones.end() ){
    delete p->second;
    cout << "Protagonista delete estado: " << p->first << endl;
    p++;
  }

#ifndef DEBUG
  cout << "Protagonista::~Protagonista()" << endl;
#endif 
}

void Protagonista::actualizar(){
  // establecemos la posición de la ventana
  juego->nivel->ventana->set_destino( x - FOCO_WIDTH, y - FOCO_HEIGHT );

  // si somos invulnerables, disminuimos duracion por cada ciclo
  if( super ) --super;

  // si no estamos en el mismo estado 
  if( estado != estado_anterior ){
    // comenzamos la animación y guardamos el estado
    animaciones[estado]->reiniciar();
    estado_anterior = estado;
  }

  // implementación del autómata según sea el estado
  switch( estado ) {

  case APPEAR: state_appear(); break;
  case PARADO: estado_parado(); break;
  case CAMINAR: estado_caminar(); break;
  case GOLPEAR: estado_disparar(); break;
  case SALTAR: estado_saltar(); break;
  case MORIR: estado_morir(); break;
  case DAMAGE: state_damage(); break;
  case SUPER: estado_super(); break;
			
  default:
    cerr << "Protagonista::actualizar ERR : Estado no contemplado" << endl;
    break;
  }
}

void Protagonista::colisiona_con( Participante *otro ){
 if( estado != MORIR && super == 0 ){
   int pv_init = puntos_vitales;

    // realizamos el daño segun el tipo de enemigo
    switch( otro->get_tipo() ) {

    case TIPO_ENEMIGO_AOK: disminuir_pv( 4 ); break;
    case TIPO_ENEMIGO_BOK: super = 50; disminuir_pv( 1 ); break;
    case TIPO_ENEMIGO_DOK: disminuir_pv( 3 ); break;
    case TIPO_ENEMIGO_FOK: super = 50; disminuir_pv( 2 ); break;
    case TIPO_ENEMIGO_GOK: disminuir_pv( 5 ); break;
    case TIPO_ENEMIGO_LOK: disminuir_pv( 3 ); break;
    case TIPO_ENEMIGO_ROK: disminuir_pv( 3 ); break;
    case TIPO_FIRE_LOK: 
      super = 20; 
      disminuir_pv( 1 ); 
      otro->colisiona_con( this ); 
      break;
    case TIPO_KEY:break;
    default: 
      cerr << "Protagonista::colisiona_con() ERR : case no contemplado" << endl;
      break;
    }
    if( puntos_vitales > 0 ){ 
      if( pv_init - puntos_vitales >= 3 ){
	velocidad_salto = -3; estado = DAMAGE; super = 180;
      } else {
	if( otro->get_posicion() >= 1 ) mover_sobre_x( -5 );
	else if( otro->get_posicion() <= 1 ) mover_sobre_x( 5 );
      }
    } else {
      /* tomamos la posicion de muerte para establecer al heroe en el mismo punto */
      x0 = x;
      y0 = y - HERO_Y_APPEAR;
      estado = MORIR;            /* muere el personaje */
      velocidad_salto = 0;       /* hace el efecto de morir */
    } 
  }
}

void Protagonista::reiniciar(){
  // reestablecemos el personaje
  x = x0;
  y = y0;
  direccion = 1;

  estado = APPEAR;
  velocidad_salto = 0;
  estado_anterior = estado;
}

void Protagonista::state_appear(){
  static float paso = HERO_Y_APPEAR / ( animaciones[ estado ]->get_size() ); 
  float distance = y - y0;
  static int anterior = 0;
  int actual;

  velocidad_salto += HERO_V_JUMP;
  y += (int)velocidad_salto;
  super = 180;

  if( ( actual = (int)( distance / paso ) ) != anterior ){
    anterior = actual;

    if( animaciones[ estado ]->avanzar() ){
      estado = SALTAR;
      velocidad_salto = 0;
    }
  }
}


// funciones que implementan el diagrama de estados
void Protagonista::estado_parado(){
  // estando parado podemos realizar las siguientes acciones
  if( teclado->pulso( LEFT ) ) { direccion = -1; estado = CAMINAR; }
  if( teclado->pulso( RIGHT ) ) { direccion = 1; estado = CAMINAR; }
  if( teclado->pulso( KO ) ) estado = GOLPEAR;
  if( teclado->pulso( XUPER ) ) if( puntos_vitales < 6 ) estado = SUPER;
  if( teclado->pulso( JUMP ) ) { velocidad_salto = HERO_LIMIT_JUMP; estado = SALTAR; }
  if( !pisa_el_suelo() ) { velocidad_salto = 0; estado = SALTAR; }
}

void Protagonista::estado_caminar(){
  // acciones que podemos realizar mientras caminamos
  animaciones[ estado ]->avanzar();

  mover_sobre_x( direccion * HERO_V_WALK );

  // al no precionar derecha-izquierda se cambia de estado
  if( direccion == 1 && ! teclado->pulso( RIGHT ) ) estado = PARADO;
  if( direccion == -1 && ! teclado->pulso( LEFT ) ) estado = PARADO;

  if( teclado->pulso( KO ) ) estado = GOLPEAR;
  if( teclado->pulso( XUPER ) ) if( puntos_vitales < 6 ) estado = SUPER;
  if( teclado->pulso( JUMP ) ) { velocidad_salto = HERO_LIMIT_JUMP; estado = SALTAR; }

  if( !pisa_el_suelo() ) { velocidad_salto = 0; estado = SALTAR; }
}

void Protagonista::estado_disparar(){
  int frame = animaciones[ estado ]->get_frame();

  if( animaciones[ estado ]->fin( frame ) ){
    if( frame % 2 == 0 ) mover_sobre_x( direccion * 5 );
    else mover_sobre_x( direccion * - 4 );
  }

  // si se termina la animacion cambiamos de estado
  if( animaciones[ estado ]->avanzar() ){
    if( teclado->pulso( KO ) ) animaciones[ estado ]->reiniciar();
    else estado = PARADO;
  }

  if( !pisa_el_suelo() ) { velocidad_salto = 0; estado = SALTAR; }
}

void Protagonista::estado_super(){
  mover_sobre_x( direccion * 3 );

  // si se termina la animacion cambiamos de estado
  if( animaciones[ estado ]->avanzar() )
    estado = PARADO;

  if( !pisa_el_suelo() ) { velocidad_salto = 0; estado = SALTAR; }
}

void Protagonista::estado_saltar(){
  static bool subir = true, caer = false;
  static float paso = HERO_LIMIT_JUMP / ( animaciones[ estado ]->get_size() / 2 ); 
  static int actual = 0;

  /* mientras el salto se mantenga precionado se segura elevando asta llegar
     al limite establecido, else: se comienza a caer */
  if( teclado->pulso( JUMP ) && subir == true ) 
    velocidad_salto += HERO_V_JUMP;
  else {
    if( subir == true ){ velocidad_salto = 0.0; subir = false; }

    velocidad_salto += HERO_V_JUMP;
  }

  // movimientos horizontales durante la caida
  if( teclado->pulso( LEFT ) ){
    direccion = -1;
    mover_sobre_x( direccion * HERO_VJ_LEFT );
  }

  if( teclado->pulso( RIGHT ) ){
    direccion = 1;
    mover_sobre_x( direccion * HERO_VJ_RIGHT );
  }

  // si se comienza la caida se establece el frame de animacion correcto
  if( velocidad_salto >= 0 && caer == false ){
    caer = true; 
    animaciones[ estado ]->set_frame( 14 );
  } 

  // se avanza la animacion conforme la altura para el ascenso
  if( ( int( velocidad_salto / paso ) != actual ) && velocidad_salto <= 0 ){
    actual = velocidad_salto / paso;
    animaciones[ estado ]->avanzar();
  }
  // se avanza la animacion conforme la altura para el descenso
  else if( (  int(velocidad_salto / paso) != actual ) && !animaciones[ estado ]->fin() ){
    actual = velocidad_salto / paso;
    animaciones[ estado ]->avanzar();
  }

  // cuando la velocidad cambia de signo empezamos a caer
  if( velocidad_salto >= 0.0 ){
    y += altura( (int)velocidad_salto );

    if( velocidad_salto >= 0.0 && pisa_el_suelo() ){
      estado = PARADO;
      subir = true;
      caer = false;
    }

    // si llega al limite vertical muere
    if( y > NIV_HEIGHT )
      estado = MORIR;
  }
  else
    y += (int)velocidad_salto;
}

void Protagonista::estado_morir(){
  set_pv();  // establecemos los puntos vitales a cero

  // cuando la animacion termina cambiamos de estado
  if( animaciones[ estado ]->avanzar() ){
    reiniciar();
    set_pv( HERO_PV );
  }
}

void Protagonista::state_damage(){
  velocidad_salto += HERO_V_JUMP;
  mover_sobre_x( -( direccion * HERO_VJ_RIGHT ) );
  y += (int)velocidad_salto;

  if( animaciones[ estado ]->avanzar() ){
    velocidad_salto = 0;
    estado = PARADO;
  }

  if( animaciones[ estado ]->get_frame() > 45 ){
    if( juego->nivel->altura( x, y ) ){
      velocidad_salto = 0;
      estado = PARADO;
    }
  }
}
