Emacs major mode for fish shell scripts.

Check fish-mode.el for more information.

# Installation #
[![MELPA](http://melpa.org/packages/fish-mode-badge.svg)](http://melpa.org/#/fish-mode)
[![MELPA Stable](http://stable.melpa.org/packages/fish-mode-badge.svg)](http://stable.melpa.org/#/fish-mode)

Available on [MELPA](http://melpa.org/#/fish-mode):

    M-x package-install fish-mode
