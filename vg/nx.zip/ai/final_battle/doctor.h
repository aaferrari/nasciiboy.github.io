
#ifndef _DOCTOR_H
#define _DOCTOR_H

extern int crystal_xmark, crystal_ymark;
extern bool crystal_tofront;


#endif
