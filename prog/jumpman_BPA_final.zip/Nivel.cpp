// Listado: Nivel.cpp 
// Implementación de la clase Nivel
#include <iostream>
#include <SDL/SDL_image.h>
#include <cstdio>
#include <cstring>

#include "Nivel.h"
#include "Control_Juego.h"
#include "Universo.h"
#include "Protagonista.h"
#include "Juego.h"
#include "Imagen.h"
#include "Galeria.h"

using namespace std;

Nivel::Nivel( Universo *universo, int index, int filas, int columnas ){
  // inicializamos las variables
  this->universo = universo;
  this->tl = universo->galeria->get_imagen( Galeria::TILES );
  this->bk = universo->galeria->get_imagen( Galeria::TILES_BK );
  this->filas = filas;
  this->columnas = columnas;
  fichero = NULL;
  fondo = NULL;
  modificado = false;
  ventana = new Ventana( filas, columnas );

  abrir_fichero();
  set_nivel( index );    // cargamos el fichero

#ifdef DEBUG
  cout << "Nivel::Nivel()" << endl;
#endif
}

Nivel::~Nivel(){
  delete ventana;
  cerrar_fichero();

  if( fondo != NULL ) SDL_FreeSurface( fondo );

#ifdef DEBUG
  cout << "Nivel::~Nivel()" << endl;
#endif
}

// se establece el nivel
bool Nivel::set_nivel( int s_n ){
  if( s_n < 0 || s_n > TOT_NIV - 1 ){
    numero_nivel = 0;
    cerr << "Nivel::set_nivel -> nivel inexistente" << endl;
    cargar();
    return false;
  }
  else {
    numero_nivel = s_n;
    if( cargar() ) return false;
    else return true;
  }
}

void Nivel::abrir_fichero(){
  fichero = fopen( "niveles.dat", "rb" );

  if( fichero == NULL ){
    cerr << "No se encuentra el fichero niveles.dat\n" 
	 << "Creando nuevo fichero: ";
    fichero = crear_fichero( "niveles.dat" );
  }
}
 
// carga el fichero de niveles
int Nivel::cargar(){
  if( fseek( fichero, numero_nivel * sizeof( Datos ), SEEK_SET ) ){
    cerr << "Sin acceso al fichero de niveles. NIVEL # " 
	 << numero_nivel << endl;
    return 1;
  }
  else {
    if( fread( &nivel, sizeof( Datos ), 1, fichero ) < 1 ){
      cerr << "No se puede cargar el fichero de niveles. NIVEL # " 
	   << numero_nivel << endl;
      return 1;
    }
#ifdef DEBUG
    else cout << "Cargado: Nivel #" << nivel.num_nivel << endl;
#endif

  }

  return 0;
}

// actualiza la ventana en la que nos encontramos
void Nivel::actualizar() { ventana->actualizar(); }

// dibuja los bloques y fondo del nivel
void Nivel::dibujar_bloques( SDL_Surface *superficie ){
  int lx, ly;                             // columna y fila que se lee del mapa
  int margen_x, margen_y;                 /* zona que se pierde al dibujar el primer 
	 				     bloque si no es múltiplo de 32 */
  int num_bloques_x, num_bloques_y;       // número de bloques a dibujar sobre x e y
  unsigned short tl_bloque, bk_bloque;    // 1 bloque - 8 bits

  ly = ventana->get_y() / TAM_BLOQUE;     // posicionamos 
  lx = ventana->get_x() / TAM_BLOQUE;     // posicionamos 

  margen_y = ventana->get_y() % TAM_BLOQUE;  // cálculo del sobrante
  margen_x = ventana->get_x() % TAM_BLOQUE;  // cálculo del sobrante

  // si hay sobrante necesitamos un bloque más
  if( margen_x == 0 )
    num_bloques_x = columnas;
  else 
    num_bloques_x = columnas + 1;

  if( margen_y == 0 )
    num_bloques_y = filas;
  else
    num_bloques_y = filas + 1;

  for( int col = 0; col < num_bloques_x; col++ ){
    for( int fil = 0; fil < num_bloques_y; fil++ ){
      tl_bloque = nivel.tiles[ fil + ly ][ col + lx ];
      // dibujamos el fondo
      if( tl_bloque == BLOQUE_VACIO );
      else if( tl_bloque >= 0 && tl_bloque < 256 ){
	tl->dibujar( superficie, tl_bloque, col * TAM_BLOQUE - margen_x, \
			  fil * TAM_BLOQUE - margen_y, 1 );
      } else {
	cerr << "Nivel::dibujar_bloques ERR : anomalia en nivel.tiles[ "
	     << fil + ly << " ][ " << col + lx << " ] = " << tl_bloque << endl;
	// correccion temporal de anomalia
        nivel.tiles[ fil + ly ][ col + lx ] = BLOQUE_VACIO;
      }

      bk_bloque = nivel.block[ fil + ly ][ col + lx ];
      // dibujamos los bloques
      if( bk_bloque == BLOQUE_VACIO );
      else if( bk_bloque >= 0 && bk_bloque < 256 ){
	bk->dibujar( superficie, bk_bloque, col * TAM_BLOQUE - margen_x, \
			  fil * TAM_BLOQUE - margen_y, 1 );
      } else {
	cerr << "Nivel::dibujar_bloques ERR : anomalia en nivel.tiles[ "
	     << fil + ly << " ][ " << col + lx << " ] = " << bk_bloque << endl;
	// correccion temporal de anomalia
	nivel.tiles[ fil + ly ][ col + lx ] = BLOQUE_VACIO;
      }
    }
  }
}

void Nivel::dibujar_actores( SDL_Surface *superficie ){
  int lx, ly;                          // columna y fila que se lee del mapa
  int margen_x, margen_y;              /* zona que se pierde al dibujar el primer 
				          bloque si no es múltiplo de 32 */
  int num_bloques_x, num_bloques_y;    // número de bloques a dibujar sobre x e y
  unsigned char bloque;                       // 1 bloque - 8 bits

  ly = ventana->get_y() / TAM_BLOQUE;  // posición según bloque
  lx = ventana->get_x() / TAM_BLOQUE;  // posición según bloque

  margen_y = ventana->get_y() % TAM_BLOQUE;  // calculamos el sobrante
  margen_x = ventana->get_x() % TAM_BLOQUE;  // calculamos el sobrante
 
  // si hay sobrante necesitamos un bloque más
  if( margen_x == 0 )
    num_bloques_x = columnas;
  else 
    num_bloques_x = columnas + 1;

  if( margen_y == 0 )
    num_bloques_y = filas;
  else
    num_bloques_y = filas + 1;

  Imagen *imagen_tmp;
  Galeria::codigo_imagen codigo_tmp;
  int x0, y0;

  for( int col = 0; col < num_bloques_x; col++ ){
    for( int fil = 0; fil < num_bloques_y; fil++ ){
      bloque = nivel.characters[ fil + ly ][ col + lx ];

      if( bloque >= 0 && bloque < 256 ){
	switch( bloque ){

	case CHARACTER_VACIO:
	  codigo_tmp = Galeria::TILES; // valor "vacio"
	  break;

	case 1:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ENEMIGO_ROK;
	  break;

	case 2:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ENEMIGO_DOK;
	  break;

	case 3:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ENEMIGO_FOK;
	  break;

	case 4:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ENEMIGO_LOK;
	  break;

	case 5:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ENEMIGO_GOK;
	  break;

	case 6:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ENEMIGO_AOK;
	  break;

	case 48:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ITEM_POWER;
	  break;

	case 49:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::ITEM_LIFE;
	  break;

	case 50:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::KEY;
	  break;

	case 0:
	  x0 = 16;
	  y0 = TAM_BLOQUE;
	  codigo_tmp = Galeria::HERO;
	  break;

	default:
	  codigo_tmp = Galeria::TILES;
	  // modificacion temporal
	  nivel.characters[ fil + ly ][ col + lx ] = CHARACTER_VACIO;
	  break;
	} // fin switch

	if( codigo_tmp != Galeria::TILES ){
	  imagen_tmp = universo->galeria->get_imagen( codigo_tmp );
	  imagen_tmp->dibujar( superficie, 0,\
			       col * TAM_BLOQUE - margen_x + x0,\
			       fil * TAM_BLOQUE - margen_y + y0, 1 );
	}
      } // fin if( bloque > 35 && bloque < 45 )
    }   // fin fil < num_bloques_y
  }     // fin col < num_bloques_x
}

void Nivel::get_actores( Control_Juego *control_juego ){
  unsigned char bloque;
  int x, y;
  bool hero = false;

#ifdef DEBUG
  cout << "\n================ CARGANDO PARTICIPANTES ACTIVOS ================" << endl;
#endif

  for( int fil = 0; fil < BQ_NIVEL_HEIGHT; fil++ ){
    for( int col = 0; col < BQ_NIVEL_WIDTH; col++ ){
      // según la información del bloque
      bloque = nivel.characters[ fil ][ col ];

      x = ( col * TAM_BLOQUE ) + 16;
      y = ( fil * TAM_BLOQUE ) + TAM_BLOQUE;

      // cargamos el actor correspodiente
      switch( bloque ) {

      case CHARACTER_VACIO: break;

      case 1:
	control_juego->get_enemigo( Participante::TIPO_ENEMIGO_ROK, x, y, 1 );
	break;

      case 2:
	control_juego->get_enemigo( Participante::TIPO_ENEMIGO_DOK, x, y, 1 );
	break;

      case 3:
	control_juego->get_enemigo( Participante::TIPO_ENEMIGO_FOK, x, y, 1 );
	break;

      case 4:
	control_juego->get_enemigo( Participante::TIPO_ENEMIGO_LOK, x, y, 1 );
	break;

      case 5:
	control_juego->get_enemigo( Participante::TIPO_ENEMIGO_GOK, x, y, 1 );
	break;

      case 6:
	control_juego->get_enemigo( Participante::TIPO_ENEMIGO_AOK, x, y, 1 );
	break;

      case 48:
	control_juego->get_item( Participante::TIPO_ITEM_POWER, x, y, 1 );
	break;


      case 49:
	control_juego->get_item( Participante::TIPO_ITEM_LIFE, x, y, 1 );
	break;

      case 50:
	control_juego->get_enemigo( Participante::TIPO_KEY, x, y, 1 );
	break;

      case 0:
	control_juego->get_protagonista( x, y, 1 );
	hero = true;
	break;

      default:
	cerr << "Nivel::get_actores ERR : anomalia en nivel.characters[ "
	     << fil << " ][ " << col << " ] = " << bloque << endl;
	// correcion temporal
	nivel.characters[ fil ][ col ] = CHARACTER_VACIO;
	break;
      } // fin switch
    }   // fin fil < BQ_NIVEL_WIDTH
  }     // fin col < BQ_NIVEL_HEIGHT

  // si no se encuentra un protagonista se proporciona uno
  if( hero == false )
    control_juego->get_protagonista( 0, 0, 1 );

#ifdef DEBUG
  cout << "================ PARTICIPANTES ACTIVOS CARGADOS ================\n" << endl;
#endif
}

// calcula la posicion de un elemento, regresa un valor con respecto a esta
int Nivel::altura( int x, int y, int rango ){
  // indicamos si estamos fuera de la ventana
  if( x < 0 || x >= NIV_WIDTH || y < 0 || y >= NIV_HEIGHT )
    return rango;

  int fila, columna;

  for( int h = 0; h < rango; h++ ){
    columna = x / TAM_BLOQUE;
    fila = ( y + h ) / TAM_BLOQUE;

    if( ( y + h ) % TAM_BLOQUE == 0 && 
	no_es_traspasable( nivel.block[ fila ][ columna ] ) )
      return h;
  }

  return rango;
}

// calcula la posicion de un elemento, regresa un valor con respecto a esta
int Nivel::altura( int x, int y ){
  // indicamos si estamos fuera de la ventana
  if( x < 0 || x >= NIV_WIDTH || y < 0 || y >= NIV_HEIGHT )
    return -1;

  int fila, columna;

  for( int h = 0; h < 6; h++ ){
    columna = x / TAM_BLOQUE;
    fila = ( y + h ) / TAM_BLOQUE;

    if( ( y + h ) % TAM_BLOQUE == 0 && 
	no_es_traspasable( nivel.block[ fila ][ columna ] ) )
      return 1;
  }

  return 0;
}

// devuelve true si un elemento no es traspasable
bool Nivel::no_es_traspasable( int codigo ){
  /* codigo de la rejilla de los bloques. En la imagen que almacena los 
     tiles estos elementos son los que están definidos como no transpasables */
  if( codigo >= 0 && codigo < 255 )
    return true;
  else
    return false;
}

/* esta función edita el bloque actual. Si se le pasa -1 en i, limpia 
   el bloque, las posiciones x e y son relativas */
void Nivel::editar_bloque( int capa, int i, int x, int y ){
  if( capa >= 0 && capa < 3 ){
    if( i >= 0 && i < 256 ){
      // calculamos la posición absoluta
      int fila_destino = ( y + ventana->get_y() ) / TAM_BLOQUE;
      int columna_destino = ( x + ventana->get_x() ) / TAM_BLOQUE;

      if( fila_destino > BQ_NIVEL_HEIGHT || columna_destino > BQ_NIVEL_WIDTH ){
	// no realizamos niguna accion
      } else {
        switch( capa ) {
          // marcamos el bloque de la capa correspondiente
        case 0 : nivel.tiles[ fila_destino ][ columna_destino ] = i; break;
        case 1 : nivel.block[ fila_destino ][ columna_destino ] =
            ( i < 104 || i > 253 ) ?  i : BLOQUE_VACIO; break;
        case 2 : nivel.characters[ fila_destino ][ columna_destino ] = 
            ( i < 7 || i == 48 || i == 49 || i == 50 ) ? i : BLOQUE_VACIO; break;
        }

        modificado = true; // se activa la opción de guardar el nivel modificado
#ifdef DEBUG
        cout << "Nivel::editar_bloque Modificacion capa#" << capa << " elemento#" << i << endl;
#endif
      } 
    } else cerr << "Nivel::editar_bloque ERR : elemento #" << i  
		<< " no contemplado" << endl;
  } else cerr << "Nivel::editar_bloque ERR : capa #" << capa  
	      << " no contemplada" << endl;
}

// esta función almacena el mapa en un fichero
void Nivel::guardar(){
  FILE * salida;

  if( modificado == false ){
    cerr << "Nivel::guardar() -> Nivel #" << numero_nivel 
         << " no modificado, no se almacenará" << endl;
    return;
  }

  salida = fopen( "niveles.dat", "rb+" );

  // si no existe, intentamos crear un fichero
  if( salida == NULL ){
    salida = crear_fichero( "niveles.dat" );

    // no podemos crearlo
    if( salida == NULL ){ 
      cerr << "Nivel::guardar() -> Sin acceso de "
	   << "escritura al sistema de ficheros" << endl;
      return;
    }
  }

  if( fseek( salida, numero_nivel * sizeof( Datos ) , SEEK_SET ) ){
    cerr << "Nivel::guardar() -> Error en el fichero. Nivel #"
         << numero_nivel << endl;
    fclose( salida );
    return;
  }
  else {
    if( fwrite( &nivel, sizeof( Datos ), 1, salida ) < 1 ){
      cerr << "Nivel::guardar() -> Error de "
	   << "escritura en el fichero. Nivel #" << numero_nivel << endl;

      fclose( salida );
      return;
    }
    else
      cout <<  "Nivel::guardar() -> exito al guardar nivel #" 
           << numero_nivel << endl;
  }

  modificado = false;    // Una vez guardado, ya no está modificado

  fclose( fichero );

  fflush( salida );
  fichero = salida;
}

// limpia el mapa del nivel, rellena a 255 todas las posiciones
void Nivel::limpiar( int capa ){
  switch( capa ) {
  case 0: 
    for( int h = 0; h < BQ_NIVEL_HEIGHT; h++ ){
      for( int w = 0; w < BQ_NIVEL_WIDTH; w++ )
        nivel.tiles[ h ][ w ] = BLOQUE_VACIO;
    }
    break;
  case 1:
    for( int h = 0; h < BQ_NIVEL_HEIGHT; h++ ){
      for( int w = 0; w < BQ_NIVEL_WIDTH; w++ )
        nivel.block[ h ][ w  ] = CHARACTER_VACIO;
    }
    break;
  case 2:
    for( int h = 0; h < BQ_NIVEL_HEIGHT; h++ ){
      for( int w = 0; w < BQ_NIVEL_WIDTH; w++ )
        nivel.characters[ h ][ w  ] = CHARACTER_VACIO;
    }
    break;
  default:
    for( int h = 0; h < BQ_NIVEL_HEIGHT; h++ ){
      for( int w = 0; w < BQ_NIVEL_WIDTH; w++ ){
        nivel.tiles[ h ][ w ] = BLOQUE_VACIO;
        nivel.characters[ h ][ w  ] = CHARACTER_VACIO;
        nivel.block[ h ][ w  ] = CHARACTER_VACIO;
      }
    }
  }
}

// pasa de nivel
int Nivel::siguiente(){
  if( numero_nivel < TOT_NIV - 1 ){
    numero_nivel++;

    // si no podemos acceder a un nivel más( no existe, o fallo )
    if( cargar() ){
      numero_nivel--;
      return ERR_LOAD_NIVEL;
    } else return FULL_LOAD_NIVEL;
  }
  else return FIN_JUEGO;
}

// pasa al nivel anterior
void Nivel::anterior(){
  // nivel inicial es el 0
  if( numero_nivel > 0 ){
    numero_nivel--;
    cargar();
  }
}

int Nivel::get_index() { return numero_nivel; }

void Nivel::cerrar_fichero(){
  // si existe el fichero
  if( fichero ){
    fclose( fichero ); // Lo cerramos
    fichero = NULL;
  }
  else
    cerr << "El fichero de niveles no estaba abierto" << endl;
}

FILE *Nivel::crear_fichero( const char *name ){
  FILE *tmp;
  Datos tmp_nivel;

  tmp = fopen( name, "wb+" );

  if( tmp == NULL )
    cerr << "No se puede crear el fichero niveles.dat" << endl;
  else {
    // ya creado le damos niveles en blanco.
    for( int h = 0; h < BQ_NIVEL_HEIGHT; h++ ){
      for( int w = 0; w < BQ_NIVEL_WIDTH; w++ ){
	tmp_nivel.tiles[ h ][ w ] = BLOQUE_VACIO;
	tmp_nivel.characters[ h ][ w  ] = CHARACTER_VACIO;
	tmp_nivel.block[ h ][ w  ] = CHARACTER_VACIO;
      }
    }

    for( int niv = 0; niv < TOT_NIV; niv++ ){
      tmp_nivel.num_nivel = niv;
      fseek( tmp, niv * sizeof( Datos ), SEEK_SET );
      fwrite( &tmp_nivel, sizeof( Datos ), 1, tmp );
    }

    fseek( tmp, 0, SEEK_SET );
#ifdef DEBUG
    cout << "Fichero de niveles creado -> " << name << endl;
#endif
  }

  return tmp;
}

/* copiamos el fichero abierto a nuestro fichero de niveles 
   para facilitar la edición */
void Nivel::copiar_fichero( FILE * tmp ){
  Datos tmp_nivel;

  for( int niv = 0; niv < TOT_NIV; niv++ ){
    // copiamos el fichero, nivel a nivel
    fseek( fichero, niv * sizeof( Datos ), SEEK_SET );
    fseek( tmp, niv * sizeof( Datos ), SEEK_SET );

    fread( &tmp_nivel, sizeof( Datos ), 1, fichero );
    fwrite( &tmp_nivel, sizeof( Datos ), 1, tmp );
  }

#ifdef DEBUG
  cout << "Almacenado fichero de niveles" << endl;
#endif
}
