// Listado: Imagen.h
// Clase par gestionar el trabajo con imagenes y rejillas
#ifndef IMAGEN_H
#define IMAGEN_H

#include <SDL/SDL.h>

#include "Common_Const.h"

class Imagen {
 public:
  Imagen( const char *path, int filas = 1, int columnas = 1,
	  int x = 0, int y = 0, bool alpha = false, 
	  Uint8 r = CK_R, Uint8 g = CK_G, Uint8 b = CK_B ); // constructor predeterminado
  ~Imagen();                                                // destructor

  void dibujar( SDL_Surface *superficie, int rejilla = 0,
		int x = 0, int y = 0, int flip = 1 );       // coloca la rejilla en pantalla
  int get_w();         // consultora
  int get_h();         // consultora
  int get_x();         // consultora
  int get_y();         // consultora
  int get_frames();    // consultora

 private:
  SDL_Surface *imagen, *imagen_invertida;                   /* almacenan la imagen que contiene
							       las rejillas de animacion */

  int columnas, filas;  // propiedades de la rejilla de imagen
  int w, h;             // ancho y alto por frame o recuerdo de la animacion
  int x0, y0;           // coordenadas origen
  Uint32 colorkey;      // color de transparencia

  // invierte la imagen en horizontal
  SDL_Surface *invertir_imagen( SDL_Surface *imagen );
};

#endif
