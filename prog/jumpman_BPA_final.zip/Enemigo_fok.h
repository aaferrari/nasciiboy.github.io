// Listado: Enemigo_fok.h
/* Clase Enemigo_fok, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef ENEMIGO_FOK_H
#define ENEMIGO_FOK_H

#include "Enemigo.h"

class Juego;

class Enemigo_fok : public Enemigo {
 public:
  Enemigo_fok( enum tipo_participantes tipo, Juego *juego,
	       int x, int y, int direccion = 1 );
  virtual ~Enemigo_fok();

  virtual void actualizar();
};

#endif
