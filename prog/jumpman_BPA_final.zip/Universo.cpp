// Listado: Universo.cpp
// Implementación de la clase Universo
#include <iostream>

#include "Universo.h"
#include "Juego.h"
#include "Editor.h"
#include "Menu.h"
#include "Intro.h"
#include "End.h"
#include "Galeria.h"
#include "Common_Const.h"
#include "Nivel.h"
#include "Control_Juego.h"

using namespace std;

Universo::Universo(){
  sdl_init( &pantalla, &icon );          // funcion externa para inicializar ventana

  // creamos todo lo necesario
  galeria = new Galeria;
  juego = new Juego( this );
  editor = new Editor( this );
  menu = new Menu( this );
  intro = new Intro( this );
  end = new End( this );
  colorbg = SDL_MapRGB( pantalla->format, UN_BG_R, UN_BG_G, UN_BG_B ); 

  salir = false;                         // no queremos salir( todavía )
  actual = juego;                        // establecemos escena actual
  set_interfaz( Interfaz::ESCENA_INTRO ); // Cambiamos a menu

#ifdef DEBUG
  cout << "Universo::Universo()" << endl;
#endif
}

Universo::~Universo(){
  delete juego;
  delete galeria;
  delete editor;
  delete menu;
  delete intro;
  delete end;

#ifdef DEBUG
  cout << "Universo::~Universo()\n"
       << "\n<< THIS IS THE END MY FRIEND ###############" << endl;
#endif
}

void Universo::set_interfaz( Interfaz::escenas nueva ){
  Interfaz *anterior = actual;

  // según sea la escena a la que queremos cambiar
  switch( nueva ) {

  case Interfaz::ESCENA_MENU: actual = menu; break;
  case Interfaz::ESCENA_JUEGO: actual = juego; break;
  case Interfaz::ESCENA_EDITOR: actual = editor; break;
  case Interfaz::ESCENA_INTRO: actual = intro; break;
  case Interfaz::ESCENA_END: actual = end; break;

  default: cerr << "Universo::set_interfaz ERR : switch() caso no contemplado"
		<< endl;
  }

  if( anterior == actual )
    cout << "Universo: Cambia a la misma escena" << endl;

  // una vez cambiada a la nueva escena, la reiniciamos
  actual->reiniciar();
}

void Universo::bucle_principal(){
  int rep;

  cout << "\n\n################## READY GO >>" << endl;
  // bucle que realiza el polling
  while( salir == false && get_evento() ){
    teclado.actualizar();           // tomamos el estado del teclado
    rep = sincronizar_fps();        // sincronizamos el tiempo

    // actualizamos lógicamente
    for( int i = 0; i < rep; i ++ )
      actual->actualizar();         // actualizamos la escena actual

    // limpiamos la pantalla
    SDL_FillRect( pantalla, NULL, colorbg );
    actual->dibujar();              // actualizamos las imágenes
  }
}

int Universo::get_evento(){
  static SDL_Event event; // con "memoria"

  // hacemos el polling de enventos
  while( SDL_PollEvent( &event ) ){
    // se estudia
    switch( event.type ){

    case SDL_QUIT: SDL_FreeSurface( icon ); return 0;

    case SDL_KEYDOWN:
      // tecla de salida
      if( event.key.keysym.sym == CLOSE_APP )
	return 0;
      // tecla paso a pantalla completa
      if( event.key.keysym.sym == WM_CHANGE )
	fullscreen();
      break;

    default: /* no hacemos nada */ break;
    }
  }

  return 1;
}

int Universo::sincronizar_fps(){
  static int t_referencia;
  static int t_inicio = SDL_GetTicks();
  static int frecuencia = FRAMES;
  static int tmp;
  static int hz = 0;
  static int t_hz = 0;

  t_referencia = SDL_GetTicks();  // tiempo de referencia

  // actualizamos información cada segundo
  if( ( t_referencia - t_hz ) >= 1000 ){
    cout << "FPS = " << hz << endl;
    hz = 0;
    t_hz += 1000;
  }
	
  hz++;  /* cada ciclo del progrtama el contador se incrementa +1, si pasa 
	    un segundo se muestra la informacion y se reinicia la cuenta */

  // estudio del tiempo
  if( ( t_referencia - t_inicio ) >= frecuencia ){
    tmp = ( t_referencia - t_inicio ) / frecuencia;
    t_inicio += tmp *frecuencia;
    return tmp;
  } else {
    // tenemos que esperar para cumplir con la frecuencia
    SDL_Delay( frecuencia - ( t_referencia - t_inicio ) );
    t_inicio += frecuencia;

    return 1;
  }
}

void Universo::fullscreen(){
  // alterna entre pantalla completa y ventana
  if( SDL_WM_ToggleFullScreen( pantalla ) != 1 )
    cerr << "Error al Cambiar de modo: " << SDL_GetError() << endl;
}

void Universo::dibujar_rect( int x, int y, int w, int h, Uint32 color ){
  SDL_Rect rect;

  // almacenamos la variable en un rectángulo
  rect.x = x;
  rect.y = y;
  rect.h = h;
  rect.w = w;

  // dibujamos el rectángulo
  SDL_FillRect( pantalla, &rect, color );
}

void Universo::nivel_modificado(){
  int nivel_actual = juego->nivel->get_index();
  juego->nuevo( nivel_actual );
}

int Universo::modificar_nivel(){ return juego->nivel->get_index(); }

// queremos salir de la aplicación
void Universo::terminar() { salir = true; /* afecta al polling */ }
