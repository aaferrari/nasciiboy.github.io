// Listado: Control_Movimiento.cpp
// Implementación de la clase Control_Movimiento
#include <iostream>
#include <cstdlib>

#include "Control_Movimiento.h"
#include "Imagen.h"

using namespace std;

Control_Movimiento::Control_Movimiento( Imagen *imagen, int indice, int x,
                                        int y, unsigned int retardo ){
  // inicializamos los atributos de la clase
  this->imagen = imagen;
  this->x = x;
  this->y = y;
  x_destino = x;
  y_destino = y;
  delay = retardo;
  cont_delay = 0;
  this->indice = indice;
  
#ifdef DEBUG
    cout << "Control_Movimiento::Control_Movimiento()" << endl;
#endif
}

Control_Movimiento::~Control_Movimiento(){
#ifdef DEBUG
  cout << "Control_Movimiento::~Control_Movimiento()" << endl;
#endif
}

bool Control_Movimiento::actualizar(){
  // actualización de la posición del elemento
  int dx = x_destino - x;
  int dy = y_destino - y;

  if( ( ++cont_delay ) >= delay ){
    cont_delay = 0;

    // si hay movimiento
    if( dx != 0){
      // controlamos la precisión del movimiento
      if( abs( dx ) >= 10 )
        x += dx / 10;         // reducimos el movimiento unadecima parte
      else
        x += dx / abs( dx );  // reducimos el movimiento a un pixel
    }

    // identico para el movimiento vertical
    if( dy != 0 ){
      if( abs( dy ) >= 10)
        y += dy / 10;        // reducimos el movimiento unadecima parte
      else
        y += dy / abs(dy);   // reducimos el movimiento a un pixel
    }

    if( y == y_destino && x == x_destino ) return true;
  }

  return false;
}

void Control_Movimiento::dibujar( SDL_Surface *pantalla ){
  imagen->dibujar( pantalla, indice, x, y, 1 );
}

void Control_Movimiento::mover( int x, int y ){
  /* Este movimiento es actualizado por la función actualizar()
     de esta clase con la precisión que tenemos implementada en ella */
  x_destino = x;
  y_destino = y;
}

void Control_Movimiento::mover_inmediatamente( int x, int y ){
  /* Esta función nos permite hacer un movimiento inmediato
     a una determinada posición */
  mover( x, y );
  this->x = x;
  this->y = y;
}
