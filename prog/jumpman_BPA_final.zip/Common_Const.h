#ifndef _CONSTANTES_H
#define _CONSTANTES_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

// sdl_init
const Uint32 INIT_FLAGS = SDL_INIT_VIDEO;               // para iniciar subsistemas
const char WM_CAPTION[] = "test";                       // titulo ventana
const char ICON[] = "data/icon/gx-one.png";             // icono de aplicacion
const int WM_WIDTH = 720;//1000;  // 720;                               // ancho aplicacion
const int WM_HEIGHT = 480;// 600; // 480;                              // alto aplicacion
const int WM_BPP = 32;                                  // profundidad de color
const Uint32 WM_FLAGS = SDL_HWSURFACE | SDL_DOUBLEBUF;  // modo de video
const int FREQ_MIX = 22050;                             // frecuencia( hz ) de muestreo
const Uint16 FORMAT_MIX = AUDIO_S16SYS;                 // bits y tipo de sample
const int CHANNEL_MIX = 1;                              // 1( mono ) 2 ( estereo )
const int CHUNK_SIZE = 4096;                            // tamaño de cada muestra

// Fuente
const char PRE_FONT[] = "data/font/freeInbo.ttf";       // fuente predeterminada
const int TAM_FONT = 40;                                // tamaño de fuente predeterminado
const SDL_Color COLOR_FONT = { 255, 255, 255, 255 };         // color fg de fuente predeterminado

// Teclado
const SDLKey
  CLOSE_APP = SDLK_ESCAPE,                              // terminar aplicacion 
  WM_CHANGE = SDLK_f,                                   // cambio FULLSCREEM<->Ventana
  EXIT = SDLK_BACKSPACE,                                // tecla para salir
  SAVE = SDLK_s,                                        // tecla para guardar
  OK = SDLK_RETURN,                                     // tecla para confirmar
  UP = SDLK_UP,                                         // tecla para subir
  DOWN = SDLK_DOWN,                                     // tecla para bajra
  LEFT = SDLK_LEFT,                                     // tecla para movimiento izquierdo
  RIGHT = SDLK_RIGHT,                                   // tecla para movimiento derecho
  KO = SDLK_s,                                          // tecla para ataque
  XUPER = SDLK_x,
  JUMP = SDLK_a;                                        // tecla para salto

// Imagen
const Uint8 CK_R = 0;                       // para mezcla de color key
const Uint8 CK_G = 255;                     // para mezcla de color key
const Uint8 CK_B = 0;                       // para mezcla de color key
const Uint32 CK_FLAGS = SDL_SRCCOLORKEY | SDL_RLEACCEL; // flag aplicada a color key
const int SP_W = 0;                         // separacion de en pixels dentro de rejilla
const int SP_H = 0;                         // separacion de en pixels dentro de rejilla

// Nivel
const int TOT_NIV = 33;
const int NIV_WIDTH = 1280;                               // ancho nivel
const int NIV_HEIGHT = 3840;                              // alto nivel
const int TAM_BLOQUE = 32;                               // tamaño de bloque de nivel
const int NIV_DEFAULT_FILAS = ( WM_HEIGHT % TAM_BLOQUE == 0 ) ? \
  WM_HEIGHT / TAM_BLOQUE : int( WM_WIDTH / TAM_BLOQUE ) + 1;
const int NIV_DEFAULT_COLUMMNAS = ( WM_WIDTH % TAM_BLOQUE == 0 ) ? \
  WM_WIDTH / TAM_BLOQUE : int( WM_WIDTH / TAM_BLOQUE ) + 1;
const int MV_FONDO = 10;
const int ERR_LOAD_NIVEL = 0;
const int FULL_LOAD_NIVEL = 1;
const int FIN_JUEGO = 3;
const Uint8 NVM_BG_R = 250;
const Uint8 NVM_BG_G = 250;
const Uint8 NVM_BG_B = 250;
const SDL_Color NV_FONT_BG = { 0, 0, 255, 255 };

// valores de columnas y filas de la estructura que almacena el nivel
const int BQ_NIVEL_HEIGHT = ( NIV_HEIGHT % TAM_BLOQUE == 0 ) ? \
  NIV_HEIGHT / TAM_BLOQUE : int( NIV_HEIGHT / TAM_BLOQUE ) + 1;
const int BQ_NIVEL_WIDTH =  ( NIV_WIDTH % TAM_BLOQUE == 0 ) ? \
  NIV_WIDTH / TAM_BLOQUE : int( NIV_WIDTH / TAM_BLOQUE ) + 1;

// Participantes
const int TAM_SPRITE = 30;                               // ancho real de imagen
const int TAM_HH_SPRITE = 100;                  // alto real de sprite heroe
const int MAX_PV = 20;

// principal
const int FOCO_WIDTH = WM_WIDTH / 2;     // foco de la camara respecto al heroe
const int FOCO_HEIGHT = WM_HEIGHT / 2;   // foco de la camara respecto al heroe
const int HERO_V_WALK = 4;               // velocidad de avance al caminar
const int HERO_V_KO = 1; 
const float HERO_LIMIT_JUMP = -7;        // donde empieza conteo de sato
const float HERO_V_JUMP = 0.15;           // velocidad de movimiento de salto( menos es mas )
const float HERO_V_FALL = 0.15;          
const int HERO_VJ_RIGHT = 2;             // velocidad de mivimiento de salto
const int HERO_VJ_LEFT = 2;              // velocidad de mivimiento de salto
const int HERO_PV = 20;
const int HERO_Y_APPEAR = 100;

// Universo
const int FRAMES = 16;                      // 66 frames por segindo
const Uint8 UN_BG_R = 159;
const Uint8 UN_BG_G = 182;
const Uint8 UN_BG_B = 205;

// Galeria
const char IMG_HERO[] = "data/img/inbo.png";                // rejilla inbo
const char IMG_KEY[] = "data/img/kill_key.png";             // rejilla key
const char IMG_TILES[] = "data/img/tiles_vg.png";           // tiles para fondo
const char IMG_TILES_ED[] = "data/img/tiles_ed.png";        // imagenes de herramientas
const char IMG_TILES_BK[] = "data/img/tiles_bk.png";        // tiles de bloques
const char IMG_TILES_CH[] = "data/img/tiles_ch.png";        // tiles de personajes
const char IMG_AOK[] = "data/img/kill_aok.png";             // rejilla aok
const char IMG_BOK[] = "data/img/kill_bok.png";             // rejilla bok
const char IMG_DOK[] = "data/img/kill_dok.png";             // rejilla dok
const char IMG_FOK[] = "data/img/kill_fok.png";             // rejilla fok
const char IMG_GOK[] = "data/img/kill_gok.png";             // rejilla gok
const char IMG_LOK[] = "data/img/kill_lok.png";             // rejilla lok
const char IMG_ROK[] = "data/img/kill_rok.png";             // rejilla rok
const char IMG_FIRE_LOK[] = "data/img/fire_lok.png";        // rejilla fire
const char IMG_INBO[] = "data/img/menu_inbo.png";           // titulo del menu
const char IMG_GNU[] = "data/img/GNU_30th.png";             // banner GNU
const char IMG_SDL[] = "data/img/SDL_Logo.png";             // banner SDL
const char IMG_I[] = "data/img/intro_I.png";                // '&' del intro
const char IMG_POWER[] = "data/img/item_power.png";         // rejilla power
const char IMG_LIFE[] = "data/img/item_life.png";           // rejilla life

const char TTF_MENU[] = "data/font/FreeSansBold.ttf";

const char MUS_MENU[] = "data/mus/menu.ogg";
const char MUS_EDITOR[] = "data/mus/editor.ogg";
const char MUS_JUEGO[] = "data/mus/juego.ogg";
const char MUS_END[] = "data/mus/end.ogg";

const char SFX_ITEM[] = "data/sfx/item.wav";
const char SFX_MALO[] = "data/sfx/malo.wav";    
const char SFX_NIVEL[] = "data/sfx/nivel.wav";  
const char SFX_MENU[] = "data/sfx/menu.wav";
const char SFX_BUENO[] = "data/sfx/muere.wav";

// Apuntador
const int IMAGEN_PUNTERO = 0;
const int TAM_TITLE = 32;
const unsigned char BLOQUE_VACIO = 255;
const unsigned char CHARACTER_VACIO = 255;

// Control_Juego
const int RADIOACTIVE = 200;
const int RADIO_COLISION = 40;

// Editor
const int ED_COLUMN = 8;
const int ED_MAX_FIL = 22;
const int ED_WIDTH = TAM_BLOQUE * ED_COLUMN;
const int ED_HEIGHT = WM_HEIGHT;
const int ED_X = WM_WIDTH - ED_WIDTH;
const int COLUMNAS_ZONA_EDITABLE = int( ED_X / TAM_BLOQUE );       // 17 * 32 = 544
const int FILAS_ZONA_EDITABLE = int( WM_HEIGHT / TAM_BLOQUE );          // 15 * 32 = 480
const Uint8 ED_BG_R = 0;
const Uint8 ED_BG_G = 255;
const Uint8 ED_BG_B = 0;


// Musica
const unsigned MUSIC_VOL = 60;

// Menu
const int NUM_OPCIONES = 3;
const Uint8 MN_BG_R = 0;
const Uint8 MN_BG_G = 0;
const Uint8 MN_BG_B = 0;
const int BLOQUES_NIVEL = BQ_NIVEL_WIDTH * BQ_NIVEL_HEIGHT; // ancho nivel( fseek )

#endif
