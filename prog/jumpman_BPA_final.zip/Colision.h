// Listados: Colision.h
// Toma dos objetos Participante y compara sus "rectangulos"
#ifndef COLISION_H
#define COLISION_H

class Participante;

bool colision( Participante *uno, Participante *otro);

#endif
