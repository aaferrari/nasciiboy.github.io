// Listado:Texto.cpp
// Implementación de la clase Texto
#include <iostream>

#include "Fuente.h"
#include "Texto.h"

using namespace std;

Texto::Texto( Fuente *fuente, int x, int y, const char *cadena ){
  // iniciamos las variables
  this->fuente = fuente;
  this->x = x;
  this->y = y;

  // copiamos la cadena a nuestro texto
  texto = new char[ strlen( cadena ) + 1 ];
  if( texto == NULL ){
    cerr << "Texto: Memoria para texto no asignada." << endl;
    exit( 1 );
  }

  strcpy( texto, cadena );

#ifdef DEBUG
  cout << "Texto::Texto()" << endl;
#endif
}

Texto::~Texto(){ 
  delete [] texto;

#ifdef DEBUG
  cout << "Texto::~Texto()" << endl;
#endif
}

void Texto::dibujar( SDL_Surface * pantalla, SDL_Color color ){
  // dibujamos el texto en pantalla
  fuente->palabra( pantalla, texto, x, y, color );
}

void Texto::actualizar(){ /* no realiza ninguna acción en particular */ }
