// Listado: Enemigo_dok_rok.h
/* Clase Enemigo_dok_rok, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef ENEMIGO_DOK_ROK_H
#define ENEMIGO_DOK_ROK_H

#include "Enemigo.h"

class Juego;

class Enemigo_dok_rok : public Enemigo {
 public:
  Enemigo_dok_rok( enum tipo_participantes tipo, Juego *juego,
                   int x, int y, int direccion = 1 );
  virtual ~Enemigo_dok_rok();

  virtual void actualizar();
};

#endif
