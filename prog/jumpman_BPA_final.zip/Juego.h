// Listado: Juego.h
/* Esta clase hija de interfaz nos permite relacionar el control del juego
   con los niveles para cohesionar los módulos */
#ifndef JUEGO_H
#define JUEGO_H

#include <SDL/SDL.h>

#include "Interfaz.h"

class Universo;
class Control_Juego;
class Nivel;

class Juego : public Interfaz {
 public:
  Juego( Universo *universo );  // constructor
  ~Juego();                     // destructor  

  void reiniciar();             // funcion heradada
  void actualizar();            // funcion heradada
  void dibujar();               // funcion heradada
  void nuevo( int index = 0 );  // borra el nivel y recarga
  void set_nivel( int s_n = 0); // establece el nivel solicitado

  Control_Juego *control_juego;
  Nivel *nivel;
};

#endif
