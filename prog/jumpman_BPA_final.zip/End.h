// Listado: End.h
// Esta clase controla los aspectos relevantes al Menú de la aplicación
#ifndef _END_H
#define _EDN_H

#include <SDL/SDL.h>

#include "Interfaz.h"
#include "Common_Const.h"
#include "Universo.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Sonido.h"
#include "Teclado.h"
#include "Control_Movimiento.h"
#include "Fuente.h" 
#include "Texto.h"
#include "Musica.h"

const int NUM_STRINGS = 2; 

class End: public Interfaz {
 public:
  End( Universo *universo );  // constructor
  ~End();                     // destructor

  // funciones heradas de Interfaz operativa de la clase
  void reiniciar ();
  void actualizar ();
  void dibujar ();

 private:
  Control_Movimiento *inbo;    // para el titulo del juego

  void get_titulo();           // crea los títulos del juego
  void get_strings();          // crea las cadenas que se almacenarán en cadena_opciones

  int delay;
  Uint32 END_BG_COLOR;          // color de fondo para el menu
  Teclado *teclado;             // controla el dispositivo de entrada
  Texto *end_chars[ NUM_STRINGS ];
};

#endif
