// Listado: Juego.cpp
// Implementación de la clase juego
#include <iostream>

#include "Participante.h"
#include "Juego.h"
#include "Universo.h"
#include "Nivel.h"
#include "Control_Juego.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Musica.h"

using namespace std;

Juego::Juego( Universo *universo ): Interfaz( universo ) {
  // generamos de el entorno del juego
  control_juego = new Control_Juego( this );
  nivel = new Nivel( universo );
  nivel->get_actores( control_juego );

  reiniciar();  // iniciamos el juego

#ifdef DEBUG
  cout << "Juego::Juego()" << endl;
#endif
}

Juego::~Juego(){
  delete control_juego;  // liberamos recurso
  delete nivel;          // liberamos recurso

#ifdef DEBUG
  cout << "Juego::~Juego()" << endl;
#endif
}

void Juego::reiniciar(){
    universo->galeria->get_musica( Galeria::MUSICA_JUEGO )->pausar();   
    universo->galeria->get_musica( Galeria::MUSICA_JUEGO )->reproducir();

#ifdef DEBUG
  cout << "Juego::reiniciado" << endl;
#endif
}

void Juego::actualizar(){
  // si pulsamos la tecla de salir, salimos al menu
  if( universo->teclado.pulso( EXIT ) )
    universo->set_interfaz( ESCENA_MENU );

  if( control_juego->kill() ){
    if( nivel->siguiente() == FIN_JUEGO ){
#ifdef DEBUG
      cout << "================ FIN DE JUEGO ================\n" << endl;
#endif
      set_nivel( 0 );                        // regresa al nivel cero 
      universo->set_interfaz( ESCENA_END );  // presenta el final
    }
    else {
#ifdef DEBUG
      cout << "->->->->->->->-> avanza nivel --> " << nivel->get_index() << endl;
#endif
      int pv = control_juego->get_hero();    // optenemos caracteristicas de ppa
      control_juego->kill_all();             // elimina particioantes restantes
      nivel->get_actores( control_juego );   // carga nuevos participantes
      control_juego->set_hero( pv );         // establecemos caracteristicas ppa
    }
  }

  // actualizamos la posición de la ventana
  nivel->actualizar();

  // actualizamos el estado de los items, enemigos y el personaje principal
  control_juego->actualizar();
}

void Juego::dibujar(){
  // dibujamos en la superficie principal
  // el fondo y el nivel
  nivel->dibujar_bloques( universo->pantalla );

  // los personajes, items y enemigos
  control_juego->dibujar( universo->pantalla );

  // actualizamos la pantalla
  SDL_Flip( universo->pantalla );
}

void Juego::nuevo( int index ){
  // hacemos sonar la música
  universo->galeria->get_musica( Galeria::MUSICA_JUEGO )->pausar();   
  universo->galeria->get_musica( Galeria::MUSICA_JUEGO )->reproducir();

  // si se ha iniciado el juego eliminamos los datos anteriores( restauramos )
  if( control_juego != NULL ) delete control_juego;
  if( nivel != NULL ) delete nivel;

  // generamos de nuevo el entorno del juego
  control_juego = new Control_Juego( this );
  nivel = new Nivel( universo, index );

  nivel->get_actores( control_juego );

#ifdef DEBUG
  cout << "Juego::nuevo()" << endl;
#endif
}

void Juego::set_nivel( int s_n ){
  if( !nivel->set_nivel( s_n ) )
    cerr << "juego::set_nivel -> ERROR nivel no establecido" << endl;

  control_juego->kill_all();           // elimina participantes actuales
  nivel->get_actores( control_juego ); // cargamos nuevos personajes

#ifdef DEBUG
  cout << "Juego::set_nivel()" << endl;
#endif
}
