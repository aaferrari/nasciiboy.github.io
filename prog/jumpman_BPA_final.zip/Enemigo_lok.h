// Listado: Enemigo_lok.h
/* Clase Enemigo_lok, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef ENEMIGO_LOK_H
#define ENEMIGO_LOK_H

#include "Enemigo.h"

class Juego;

class Enemigo_lok : public Enemigo {
 public:
  Enemigo_lok( enum tipo_participantes tipo, Juego *juego,
	       int x, int y, int direccion = 1 );
  virtual ~Enemigo_lok();

  virtual void actualizar();
};

#endif
