// Listado: Galeria.h
// Controla los elementos multimedia de la aplicación
#ifndef _GALERIA_H
#define _GALERIA_H

#include <map>

class Imagen;
class Fuente;
class Musica;
class Sonido;

using namespace std;

class Galeria {
 public:
  Galeria ();   // constructor
  ~Galeria();   // destructor

  // tipos contenidos en la galería
  enum codigo_fuente { FUENTE_MENU , FUENTE_MARCADOR, FUENTE_INTRO };
  enum codigo_musica { MUSICA_MENU, MUSICA_EDITOR, MUSICA_JUEGO, MUSICA_END };
  enum codigo_sonido { COGE_ITEM, MATA_MALO, PASA_NIVEL, EFECTO_MENU, MUERE_BUENO };
  enum codigo_imagen { TILES, TILES_CH, TILES_BK, TILES_ED, HERO, KEY, 
                       ENEMIGO_BOK, ENEMIGO_AOK, ENEMIGO_DOK, ENEMIGO_FOK, ENEMIGO_GOK, 
                       ENEMIGO_LOK, ENEMIGO_ROK,
                       FIRE_LOK,
		       ITEM_POWER, ITEM_LIFE,
                       MENU, INBO, INTRO_GNU, INTRO_SDL, INTRO_I };

  Imagen *get_imagen(codigo_imagen cod_ima);    // Consultora
  Fuente *get_fuente(codigo_fuente indice);     // Consultora
  Musica *get_musica(codigo_musica cod_music);  // Consultora
  Sonido *get_sonido(codigo_sonido cod_sonido); // Consultora

  // conjunto de imágenes y de fuentes que vamos a utilizar en la aplicación
  map<codigo_imagen, Imagen *> imagenes;
  map<codigo_fuente, Fuente *> fuentes;
  map<codigo_musica, Musica *> musicas;
  map<codigo_sonido, Sonido *> sonidos;
};

#endif
