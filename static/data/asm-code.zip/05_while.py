X = 1
E = 1
LIM  = 100

while (X<LIM):
    X = X + 2 * E
    E = E + 1
    print(X)
