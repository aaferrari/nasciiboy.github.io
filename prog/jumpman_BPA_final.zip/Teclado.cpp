// Listado: Teclado.cpp
// Implementacion de las funciones miembro para la clase Teclado
#include <iostream>

#include "Teclado.h"

using namespace std;

Teclado::Teclado() {
#ifdef DEBUG
  cout << "Teclado::Teclado()" << endl;
#endif

}

Teclado::~Teclado(){ 
  teclas = 0;

#ifdef DEBUG
  cout << "Teclado::~Teclado()" << endl;
#endif
}

void Teclado::actualizar(){
  // actualizar el estado de teclado mediante mapeo
  SDL_PumpEvents();
  teclas = SDL_GetKeyState( NULL );
}

bool Teclado::pulso( const SDLKey key ){
  // comprobamos si una tecla esta pulsada
  if( teclas[key] )
    return true;
  else
    return false;
}
