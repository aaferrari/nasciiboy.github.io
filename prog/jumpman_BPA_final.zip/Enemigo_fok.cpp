// Listado: Enemigo_fok.cpp
// Implementación de la clase Enemigo_fok
#include <iostream>

#include "Enemigo_fok.h"
#include "Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Enemigo_fok::Enemigo_fok( enum tipo_participantes tipo, Juego *juego, 
                          int x, int y, int direccion ) :
  Enemigo( juego, x, y, direccion, tipo ) {
  // según el tipo de enemigo que estemos creando
  if( tipo == TIPO_ENEMIGO_FOK ){
    imagen = juego->universo->galeria->get_imagen( Galeria::ENEMIGO_FOK );
    // creamos las animaciones para el personaje en particular
    animaciones[FLY] = new Secuencia( "0,1,2,1" , 20 );
    animaciones[GOLPEAR] = new Secuencia( "0,1,2,1", 5 );
    animaciones[MORIR] = new Secuencia( "3,4", 10 );

    SDL_Rect rect_principal[] = { { 35, 70, 30, 25 } };
    for( int i = 0; i < 1; i++ )
	add_rect( rect_principal[ i ] );
  } else
    cerr << "Enemigo_fok::Enemigo_fok() -> Enemigo no contenplado" << endl;

  // estado inicial para los enemigos
  estado = FLY;

#ifdef DEBUG
  cout << "Enemigo_fok::Enemigo_fok()" << endl;
#endif
}

Enemigo_fok::~Enemigo_fok(){
#ifdef DEBUG    
    cout << "Enemigo_fok::~Enemigo_fok" << endl;
#endif
}

void Enemigo_fok::actualizar(){
  switch( estado ) {

  case MORIR: 
    // cuando la secuencia alcance el final se cambia de estado
    if( animaciones[ estado ]->avanzar() )
      estado = ELIMINAR;
    break;

  case ELIMINAR: break;

  case FLY:
    animaciones[ estado ]->avanzar();
    if( posicion != 0 ) estado = GOLPEAR;
    if( !mover_sobre_x( direccion ) ){
      direccion *= -1;
    }
    break;

  case GOLPEAR:
    animaciones[ estado ]->avanzar();

    if( posicion == 0 ) estado = FLY;

    if( posicion < 0 && direccion == 1 ){
      if( !mover_sobre_x( direccion * 2 ) ) direccion *= -1;
    } else if( posicion > 0 && direccion == -1 ){
      if( !mover_sobre_x( direccion * 2 ) ) direccion *= -1;
    } else { 
      if( !mover_sobre_x( direccion ) ) direccion *= -1;
    }

    break;

  default: break;
  }
}
