// Listado: Control_Movimiento.h
/* La clase Control_Movimiento controla la animación externa de los personajes
   "el movimiento sobre el mapa del nivel" */
#ifndef CONTROL_MOVIMIENTO_H
#define CONTROL_MOVIMIENTO_H

#include <SDL/SDL.h>

class Imagen;

class Control_Movimiento {
 public:
  Control_Movimiento( Imagen *imagen, int indice = 0, int x = 0,
                      int y = 0, unsigned int retardo = 0 );
  ~Control_Movimiento();

  bool actualizar();
  void dibujar( SDL_Surface *pantalla );
  void mover( int x, int y );                 // modificadora
  void mover_inmediatamente( int x, int y );  // modificadora

 private:
  int
    x, y,                           // posición
    x_destino, y_destino,           // destino
    indice;                         // dentro de la rejilla especificamos qué imagen
  unsigned int delay, cont_delay;   // para el "velocidad" del movimiento
  Imagen *imagen;                   // rejilla de imágenes
};

#endif
