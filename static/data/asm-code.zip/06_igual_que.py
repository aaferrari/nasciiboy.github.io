def numigualque(vector_s, dim_s, dato_s):
      n = 0
      for i in range(dim_s):
           if vector_s[i] == dato_s:
              n = n + 1;
      return n

vector = [5, 3, 8, 5, 6, 8, 10, 4, 8, 7, 5, 7]
dim = 12
res1 = numigualque(vector, dim, 7)
res2 = numigualque(vector, dim, 8)
res = res1 + res2
