Authors
=======

- Barak A. Pearlmutter <barak+git@pearlmutter.net>
- Jonas Bernoulli <jonas@bernoul.li>
- Justin Burkett <justin@burkett.cc>
- Lele Gaifax <lele@metapensiero.it>
- Noam Postavsky <npostavs@users.sourceforge.net>
- Philipp Stephani <phst@google.com>
- Rémi Vanicat <vanicat@debian.org>
