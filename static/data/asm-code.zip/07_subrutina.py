def sumatorios(A, dim):
      B = [0]*dim
      for i in range(dim):
           B[i] = sumatorio(A[i:], dim-i)

      for i in range(dim):
           A[i] = B[i]
      return

def sumatorio(A, dim):
      suma = 0;
      for i in range(dim):
           suma = suma + A[i]
      return suma

A = [6, 5, 4, 3, 2, 1]
dim = 6
sumatorios(A, dim)
