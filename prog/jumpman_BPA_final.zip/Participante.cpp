// Listado: Participante.cpp
// Implementación de la clase Participante
#include <iostream>

#include "Universo.h"
#include "Participante.h"

using namespace std;

Participante::Participante( Juego *juego, int x, int y, int direccion ){
  // inicializamos las variables
  this->juego = juego;
  this->direccion = direccion;
  this->x = x;
  this->y = y;
  velocidad_salto = 0.0;
  puntos_vitales = 1;
  posicion = 0;

#ifdef DEBUG
  cout << "Participante::Participante()" << endl;
#endif
}

Participante::~Participante(){
#ifdef DEBUG
  cout << "Participante::~Participante()" << endl;
#endif
}

void Participante::dibujar( SDL_Surface *pantalla ){
  if( estado != ELIMINAR )
    imagen->dibujar( pantalla, animaciones[ estado ]->get_frame(),\
		     x - juego->nivel->ventana->get_x(),			\
		     y - juego->nivel->ventana->get_y(), direccion );
}

void Participante::dibujar_pv(){
  static Uint32 color_bg = SDL_MapRGB( juego->universo->pantalla->format, 255, 255, 255 );
  if( puntos_vitales > 0 )
    juego->universo->dibujar_rect( x - 20 - juego->nivel->ventana->get_x(),
				   y - juego->nivel->ventana->get_y(), 40, 4, color_bg );

  if( puntos_vitales < 7 ){
    static Uint32 color_R = SDL_MapRGB( juego->universo->pantalla->format, 255, 0, 0 );
    for( int i = 0; i < puntos_vitales; i++ ){
      juego->universo->dibujar_rect( x + i * 2 - 20 - juego->nivel->ventana->get_x(),
				     y - juego->nivel->ventana->get_y(), 2, 4, color_R );
    }
  } else if( puntos_vitales < 14 ){
    static Uint32 color_G = SDL_MapRGB( juego->universo->pantalla->format, 0, 255, 0 );
    for( int i = 0; i < puntos_vitales; i++ ){
      juego->universo->dibujar_rect( x + i * 2 - 20 - juego->nivel->ventana->get_x(),
				     y - juego->nivel->ventana->get_y(), 2, 4, color_G );
    }
  } else {
    static Uint32 color_B = SDL_MapRGB( juego->universo->pantalla->format, 0, 0, 255 );
    for( int i = 0; i < puntos_vitales; i++ ){
      juego->universo->dibujar_rect( x + i * 2 - 20 - juego->nivel->ventana->get_x(),
				     y - juego->nivel->ventana->get_y(), 2, 4, color_B );
    }
  }
}

void Participante::dibujar_pv( int xx, int yy, int width, int height ){
  static Uint32 color_bg = SDL_MapRGB( juego->universo->pantalla->format, 255, 255, 255 );
  if( puntos_vitales > 0 ){
    juego->universo->dibujar_rect( xx, yy, width, height, color_bg );

    static int h = height / MAX_PV;
    static int space = 3;

    for( int i = 0; i < MAX_PV; i++ ){
      juego->universo->dibujar_rect( xx + space, yy + height - h - i * h,
  				   width - space * 2, h - 1 );
    }

    if( puntos_vitales < 7 ){
      static Uint32 color_R = SDL_MapRGB( juego->universo->pantalla->format, 255, 0, 0 );
      for( int i = 0; i < puntos_vitales; i++ )
           juego->universo->dibujar_rect( xx + space, yy + height - h - i * h,
   				          width - space * 2, h - 1, color_R );
    } else if( puntos_vitales < 14 ){
      static Uint32 color_B = SDL_MapRGB( juego->universo->pantalla->format, 100, 100, 255 );
      for( int i = 0; i < puntos_vitales; i++ )
           juego->universo->dibujar_rect( xx + space, yy + height - h - i * h,
   				          width - space * 2, h - 1, color_B );
    } else {
      static Uint32 color_G = SDL_MapRGB( juego->universo->pantalla->format, 0, 255, 0 );
      for( int i = 0; i < puntos_vitales; i++ )
           juego->universo->dibujar_rect( xx + space, yy + height - h - i * h,
   				          width - space * 2, h - 1, color_G );
    }
  }
}

int Participante::get_x() { return x; };

int Participante::get_y() { return y; };

void Participante::set_pv( int pv ){
  puntos_vitales = ( pv >= 0 && pv <= MAX_PV ) ? pv : 0;
}

void Participante::set_posicion( int p ){
  posicion = ( p >= -2 && p <= 2 ) ? p : 0;
}

int Participante::get_posicion() { return posicion; }

void Participante::disminuir_pv( int pv ){
  if( puntos_vitales >= 0 )
    puntos_vitales -= ( pv >= 0 && pv <= MAX_PV ) ? pv : 0;
  if( puntos_vitales < 0 ) puntos_vitales = 0;
}

void Participante::aumentar_pv( int pv ){
  if( puntos_vitales < MAX_PV )
    puntos_vitales += ( pv >= 0 && pv <= MAX_PV ) ? pv : 0;
  if( puntos_vitales > MAX_PV ) puntos_vitales = MAX_PV;
}

bool Participante::mover_sobre_x( int incremento ){
  if( incremento > 0 ){
    // mientras se encuentre dentro del limite horizontal del nivel 
    if( x < NIV_WIDTH - TAM_SPRITE ){ x += incremento; return true; }
    else return false;
  } else {
    if( x > 30 ){
      x += incremento;
      return true;
    }
  }

return false;
}

int Participante::altura( int rango ){ 
  return juego->nivel->altura( x, y, rango ); 
}

bool Participante::pisa_el_suelo(){
  if( altura( 3 ) == 0 )
    return true;
  else
    return false;
}

bool Participante::pisa_el_suelo( int _x, int _y ){
  if( juego->nivel->altura( _x, _y, 1 ) == 0 )
    return true;
  else
    return false;
}
