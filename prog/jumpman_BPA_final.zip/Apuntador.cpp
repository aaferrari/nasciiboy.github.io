// Listado: Apuntador.cpp
// Implementación de la clase Apuntador
#include <iostream>

#include "Common_Const.h"
#include "Apuntador.h"
#include "Nivel.h"
#include "Imagen.h"
#include "Editor.h"
#include "Universo.h"

using namespace std;

// constructor
Apuntador::Apuntador( Editor *editor ) :  x( 0 ), y( 0 ), bloque_actual( 0 ) {
  this->editor = editor;  // asociamos el apuntador con el editor

#ifndef DEBUG
  cout << "Apuntador::Apuntador()" << endl;
#endif
}

Apuntador::~Apuntador(){
#ifdef DEBUG
  cout << "Apuntador::~Apuntador()" << endl;
#endif
}

void Apuntador::dibujar( SDL_Surface *pantalla ){
  // dibujamos el apuntador en su posición actual
  editor->imagen->dibujar( pantalla, IMAGEN_PUNTERO, x, y, 1 );
}

void Apuntador::actualizar(){
  // para registrar solo una pusacion en la barra herramientas  
  static bool pulsado = false; 

  // consultamos el estado del ratón
  cursor = SDL_GetMouseState( &x, &y );

  // pulsar sobre la rejilla de edicion del nivel
  if( x < COLUMNAS_ZONA_EDITABLE * TAM_BLOQUE )
    pulsa_sobre_rejilla( cursor );
  else if( x >= ED_X ){
    // pulsa en la barra de herramientas
    if( cursor == SDL_BUTTON( 1 ) ){
      if( !pulsado ){
	pulsa_sobre_barra( cursor );
	pulsado = true;
      }
    } 
    else pulsado = false;
  }
}

void Apuntador::pulsa_sobre_rejilla( Uint8 cursor ){
  // con el botón derecho eliminamos el elemento Common_const->BLOQUE_VACIO
  if( cursor == SDL_BUTTON(3) )
    editor->nivel->editar_bloque( editor->get_capa(), BLOQUE_VACIO, x, y );

  // con el izquierdo colocamos el nuevo elemento
  if( cursor == SDL_BUTTON(1) )
    editor->nivel->editar_bloque( editor->get_capa(), bloque_actual, x, y );
}

void Apuntador::pulsa_sobre_barra( Uint8 cursor ){
  int fila = y / TAM_TITLE;

  // ajusta la escala restando los bloques del area de rejillas
  /* ED_X define el puntode inicio del area de herramientas
     TAM_TITLE es el tamaño de cada elemento */
  int columna = int( ( x - ED_X ) / TAM_TITLE ); 

  // acciones segun la pulsación en pantalla
  if( fila == 0 ){
    switch( columna ){

      // sale del editor
    case 1: editor->universo->set_interfaz( Interfaz::ESCENA_MENU );
      // icono de guardar
    case 2: editor->nivel->guardar();editor->universo->nivel_modificado(); break;
      // limpia el fondo
    case 4: editor->nivel->limpiar( 0 ); break;
      // limpia los bloques
    case 5: editor->nivel->limpiar( 1 ); break;
    }
  }
  if( fila == 1 ){
    switch( columna ){

      // recarga el nivel
    case 2: editor->nivel->cargar(); break;
      // limpia los personajes
    case 4: editor->nivel->limpiar( 2 ); break;
      // limpia el nivel( TODO : bloques, fondo y personajes )
    case 5: editor->nivel->limpiar( 4 ); break;
    }
  }	
  // desplazamiento del scroll y cambio de nivel
  if( fila == 3 ){
    switch( columna ){
   
      // los valores indican el numero filas a desplazar
    case 1: editor->mover_barra_scroll( -7 ); break;
    case 2: editor->mover_barra_scroll( +7 ); break;
      // capas : fondo, bloques, personajes.
    case 3: editor->set_capa( -1 ); break;
    case 4: editor->set_capa( +1 ); break;

    case 5: editor->nivel->anterior(); break;
    case 6: editor->nivel->siguiente(); break;
    }
  }

  /* bloque, según el icono que pulsemos en el scroll es el elemento actual
     que sera colocado en el area de edicion */
  if( fila > 3 && fila < 14 )
    bloque_actual = ( fila - 4 ) * ED_COLUMN + editor->barra_scroll() * ED_COLUMN + columna;
}

int Apuntador::get_x() { return x; }
int Apuntador::get_y() { return y; }
void Apuntador::reset_bloque() { bloque_actual = 0; }
