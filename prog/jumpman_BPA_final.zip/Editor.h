// Listado: Editor.h
// Controla las características del editor de niveles
#ifndef EDITOR_H
#define EDITOR_H

#include <SDL/SDL.h>

#include "Interfaz.h"

class Universo;
class Nivel;
class Teclado;
class Imagen;
class Apuntador;

class Editor: public Interfaz {
 public:
  Editor( Universo *universo );                  // constructor
  ~Editor();                                     // destructor

  void reiniciar();                              // acciones heredadas de la clase
  void actualizar();                             // acciones heredadas de la clase
  void dibujar();                                // acciones heredadas de la clase

  void mover_barra_scroll( int desplazamiento ); // barra de menú
  int barra_scroll();                            // regresa valor de barra_scroll_
  void set_capa( int desplazamiento );           // nivel de capa
  int get_capa();                                // regresa valor del nivel de capa

  Nivel *nivel;
  Teclado *teclado;
  Imagen *imagen, *imagen_ch, *imagen_bk, *imagen_tl;   // imagenes del editor

 private:
  int x, y;                        // para el movimiento de foco
  int capa;                        // para el control sobre capa de modificacion
  int barra_scroll_;               // control sobre tiles mostrados
  Apuntador *apuntador;            // para el interactuar con la interfaz
  Uint32 ED_BG_COLOR;              // color de fondo para herramintas de edicion

  void mover_ventana();            // mueve el foco hasta alcanzar destino
  void dibujar_menu();             // redibuja el menu
  void dibujar_numero_nivel();     // muestra el nivel de pantalla
  void dibujar_separador();        // diviciones entre tiles a seleccionar
};

#endif
