// Listado: Key.h
/* Clase Key, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef KEY_H
#define KEY_H

#include "Enemigo.h"

class Juego;

class Key : public Enemigo {
 public:
  Key( enum tipo_participantes tipo, Juego *juego,
	       int x, int y, int direccion = 1 );
  virtual ~Key();

  virtual void actualizar();
};

#endif
