// Listado: Enemigo.h
/* Clase Enemigo, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef ENEMIGO_H
#define ENEMIGO_H

#include "Participante.h"

class Juego;

class Enemigo : public Participante {
 public:
  Enemigo( Juego *juego, int x, int y, int direccion,
           enum tipo_participantes tipo );
  virtual ~Enemigo();

  virtual void actualizar() = 0;
  virtual void colisiona_con( Participante *otro );
};

#endif
