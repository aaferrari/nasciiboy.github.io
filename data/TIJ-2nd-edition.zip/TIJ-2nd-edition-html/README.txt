README.txt file for Thinking in Java, 2nd Edition
Copyright (c)2000 by Bruce Eckel www.BruceEckel.com

This set of HTML files is designed to work with most web browsers. 
You will find here the entire book, "Thinking in Java, 2nd Edition"
in its current state.

This book was published in print form by Prentice Hall in June 2000. 
If you put yourself on the mailing list at http://www.BruceEckel.com 
you'll be informed of updates and publication information.

Please note:

-- To start using the frames version, open:
    >> "Frames.htm" for the abbreviated table of contents
    >> "FramXTOC.htm" for the full table of contents
    
-- To start using non-frames versions, open:
    >> Any of the "Chap??.htm" files directly; navigation is built-in
    >> "Contents.htm" for the full table of contents
    >> "SimpCont.htm" for just the Chapter titles in the table of contents
    >> "DocIndex.htm" to open the index
    
-- Remember that when you click on links within the document, you can 
   always use your browser's "back" arrow to return to where you 
   were reading.

-- If you're viewing this on Netscape under Linux, try going to 
   View|Character Set and selecting "Western (ISO-8859-15)."
   
-- The document uses fonts called Verdana and Georgia which are free downloads from:
   http://www.microsoft.com/typography/
