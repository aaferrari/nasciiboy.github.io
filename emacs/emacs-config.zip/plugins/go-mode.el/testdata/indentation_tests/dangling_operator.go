package main

func init() {
	a :=
		123

	print(123,
		456,
		789,
	)

	c :=
		"foo"

	d := // meh
		123

	e := /* meh
		another meh
		*/
		123

	println(123, /* foo
		bar */
		456,
	)

	return
}
