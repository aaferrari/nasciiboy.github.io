// Listado: Control_Juego.h
// La clase Control_Juego proporcina un mando lógico sobre el juego
#ifndef CONTROL_JUEGO_H
#define CONTROL_JUEGO_H

#include <SDL/SDL.h>
#include <list>

#include "Participante.h"
#include "Common_Const.h"

class Protagonista;
class Enemigo;
class Enemigo_aok;
class Enemigo_bok;
class Enemigo_dok_rok;
class Enemigo_fok;
class Enemigo_gok;
class Enemigo_lok;
class Fire;
class Item;
class Key;
class Juego;
class Fuente;

class Control_Juego {
 public:
  Control_Juego( Juego *juego);  // constructor
  ~Control_Juego();              // destructor

  // para realizar la actualización lógica y poder mostrar el resultado en pantalla
  void actualizar();
  void dibujar( SDL_Surface *pantalla );

  // nos permiten establecer a los participantes del juego en el universo del juego
  void get_enemigo( Participante::tipo_participantes tipo, int x, int y, int flip );
  void get_protagonista( int x, int y, int flip );
  void get_item( Participante::tipo_participantes tipo, int x, int y, int flip );
  int get_hero();
  void set_hero( int pv = 0 );

  void dibujar_marcador();       // para mostrar estados del juego y protagonista

  // para tener un control sobre los elemetos
  void kill_all();
  bool kill();

 private:
  // galería de personajes y objetos del juego
  Protagonista *protagonista_;
  list<Enemigo_aok *> lista_enemigos_aok;
  list<Enemigo_bok *> lista_enemigos_bok;
  list<Enemigo_dok_rok *> lista_enemigos_dok_rok;
  list<Enemigo_fok *> lista_enemigos_fok;
  list<Enemigo_gok *> lista_enemigos_gok;
  list<Enemigo_lok *> lista_enemigos_lok;
  list<Item *> lista_items;
  list<Fire *> lista_fires;
  list<Key *> lista_keys;
  Fuente *fuente;
  Juego *juego;
  unsigned int puntos;
  Uint32 marcador_bg;

  // para tomar coordenadas 
  void avisar_colisiones();

  // detección de colisiones
  void hay_colision( int x0, int y0, int x1, int y1,
		     Enemigo *i, int radioactive = RADIOACTIVE );
  bool hay_colision( int x0, int y0, int x1, int y1, Item *i );

  // eliminar enemigos
  void eliminar_antiguos_fires( list<Fire *>&lista );
  void eliminar_antiguos_keys( list<Key *>&lista );
  void eliminar_antiguos_items( list<Item *>&lista );
  void eliminar_antiguos_enemigos_aok( list<Enemigo_aok *>&lista );
  void eliminar_antiguos_enemigos_bok( list<Enemigo_bok *>&lista );
  void eliminar_antiguos_enemigos_dok_rok( list<Enemigo_dok_rok *>&lista );
  void eliminar_antiguos_enemigos_fok( list<Enemigo_fok *>&lista );
  void eliminar_antiguos_enemigos_gok( list<Enemigo_gok *>&lista );
  void eliminar_antiguos_enemigos_lok( list<Enemigo_lok *>&lista );
};

#endif
