// Listado: Ventana.cpp
// Implementación de la clase ventana
#include <iostream>

#include "Ventana.h"
#include "Nivel.h"
#include "Common_Const.h"

using namespace std;

Ventana::Ventana( int filas, int columnas ){
  // inicializamos las variables
  x = y = 0;
  x_final = y_final = 0;

  int w = ( columnas * TAM_BLOQUE > WM_WIDTH ) ? WM_WIDTH : columnas * TAM_BLOQUE;
  int h = ( filas * TAM_BLOQUE > WM_HEIGHT ) ? WM_HEIGHT : filas * TAM_BLOQUE;

  limite_x = NIV_WIDTH - w;
  limite_y = NIV_HEIGHT - h;

#ifdef DEBUG
  cout << "Ventana::Ventana()" << endl;
#endif
}

Ventana::~Ventana(){
#ifdef DEBUG
  cout << "Ventana::~Ventana()" << endl;
#endif
}

void Ventana::actualizar(){
  int incremento_x = x_final - x;
  int incremento_y = y_final - y;

  // si existe variación
  if( incremento_x != 0 ){
    // controlamos el movimiento de la ventan
    if( abs( incremento_x ) >= 10 )
      x += incremento_x / 10;                   // avanza una decima parte por frame
    else 
      // sobre todo en movimientos pequeños 
      x += incremento_x / abs(incremento_x);    // avanza un pixel por frame 
  }

  // si existe variación
  if( incremento_y != 0 ){
    // animación de movimiento fluida
    if( abs( incremento_y ) >= 10 )
      y += incremento_y / 10;                  // avanza una decima parte por frame
    else
      y += incremento_y / abs( incremento_y ); // avanza un pixel por frame 
  }
}

// funciones referentes al posicionamiento
void Ventana::set_destino( int x, int y ){
  x_final = x;
  y_final = y;

  limitar_movimiento();
}

void Ventana::set_actual( int x, int y ){
  x_final = this->x = ( x >= 0 && x < limite_x ) ? x : 0;
  y_final = this->y = ( y >= 0 && y < limite_y ) ? y : 0;
}

void Ventana::limitar_movimiento(){
  // comprobamos que se cumplen los límites lógicos de pantalla
  if( x_final < 0 ) x_final = 0;
  if( y_final < 0 ) y_final = 0;

  if( x_final > limite_x ) x_final = limite_x;
  if( y_final > limite_y ) y_final = limite_y;
}

void Ventana::get_destino( int *x, int *y ) { *x = x_final; *y = y_final; }

void Ventana::get_actual( int *x, int *y ) { *x = this->x; *y = this->y; }

int Ventana::get_x() { return x; }

int Ventana::get_y() { return y; }
