// Implementacion de las funciones miembro de la clase Secuencia
#include <iostream>
#include <cstring>
#include <cstdlib>

#include "Secuencia.h"

using namespace std;

Secuencia::Secuencia( const char *frames, int retardo ) : delay( retardo ) {
  char *frames_tmp, *proximo;

  frames_tmp = new char[ strlen( frames ) + 1 ];
  if( frames_tmp == NULL ){
    cerr << "Memoria dinamica para frames_tmp no asignada." << endl;
    exit( 1 );
  }

  // extraemos de la cadena separada por comas cada uno de sus elementos
  strcpy( frames_tmp, frames );

  for( proximo = strtok( frames_tmp, "," ); proximo; ){
    cuadros.push_back( atoi( proximo ) );
    proximo = strtok( NULL, ",\0" );
  }
  delete [] frames_tmp;

  // establecemos el final de la secuencia
  cuadros.push_back( -1 );

  // inicializamos las variables
  paso = 0;
  cont_delay = 0;

#ifdef DEBUG
  cout << "Secuencia::Secuencia()" << endl;
#endif
}

Secuencia::~Secuencia(){
#ifndef DEBUG
  cout << "Secuencia::~Secuencia()" << endl;
#endif
}

void Secuencia::set_frame( int nf ){
  int x = validar( nf );

  if( x != -1 ){
    paso = x;
    return;
  }
  
  cerr << "Secuencia::set_frame() ERROR: Valor no Valor #" << nf << " no valido" << endl;
}

int Secuencia::get_frame() { return cuadros[ paso ]; }

int Secuencia::get_size() { return cuadros.size() - 1; }

bool Secuencia::inicio(){
  if( paso == 0 )
    return true;

  return false;
}

bool Secuencia::fin(){
  if( ( cuadros[ paso + 1 ] == -1 ) && ( cont_delay == delay ) )
    return true;

  return false;
}

bool Secuencia::fin( int nf ){
  int x = validar( nf );

  if( x != -1 ){
    if( cuadros[ paso ] == nf && cont_delay == delay )
      return true;
  } 
  else {
    cerr << "Secuencia::fin_frame() ERROR: Valor #" << nf << " no valido" << endl;
    return false;
  }

  return false;
}


int Secuencia::avanzar(){
  // si han pasado los ciclos suficientes
  if( ( ++cont_delay ) > delay ){
    // reestablecemos el tiempo a 0
    cont_delay = 0;
	
    /* incrementamos el paso siempre que no sea el último elemento lo 
       que hará que volvamos al primer elemento */
    if( cuadros[ ++paso ] == -1 ){
      paso = 0;
      return 1;
    }
  }

  return 0;
}

void Secuencia::reiniciar() { paso = 0; cont_delay = 0; }

int Secuencia::validar( int nf ){
  for( unsigned int cont = 0; cont < cuadros.size() - 1; cont++ ){
    if( cuadros[ cont ] == nf )
      return cont;
  }
  
  cerr << "Secuencia::validar() ERROR: Valor #" << nf << " no valido" << endl;

  return -1;
}
