// Listado: Apuntador.h
/* La clase Apuntador controla el estado y la posición del cursor del ratón en 
   la pantalla. Haremos uso del cursor del ratón en el Editor de niveles */
#ifndef APUNTADOR_H
#define APUNTADOR_H

#include <SDL/SDL.h>

class Editor;

class Apuntador {
 public:
  Apuntador( Editor *editor );             // constructor
  ~Apuntador();                            // destructor

  void dibujar( SDL_Surface *pantalla );   // establece una imagen para representar el cursor
  void actualizar();                       // consulta donde se ha pulsado el cursor
  int get_x();                             // consultora de posicion
  int get_y();                             // consultora de posicion
  void reset_bloque();                     // establece a cero bloque_actual

 private:
  void pulsa_sobre_rejilla( Uint8 cursor ); // define acciones de la zona de pulsación
  void pulsa_sobre_barra( Uint8 cursor );   // define acciones de la zona de pulsación

  int 
    x, y,             // posición del cursor por cordenadas
    bloque_actual;    // contiene el identificador del elemento a colocar en el nivel
  Uint8 cursor;       // almacena la pulsación de los botones del ratón y la posicion
  Editor *editor;     // nos permite asociar el cursor con el editor de niveles
};

#endif
