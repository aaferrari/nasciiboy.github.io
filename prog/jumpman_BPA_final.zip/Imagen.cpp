// Listado: Imagen.cpp
// Definicion de las funciones miembro de la clase Imagen
#include <iostream>
#include <SDL/SDL_image.h>

#include "Imagen.h"

using namespace std;

Imagen::Imagen( const char *path, int filas, int columnas, int x, int y, bool alpha, 
		Uint8 r, Uint8 g, Uint8 b ){
  this->filas = filas;
  this->columnas = columnas;
  x0 = x;
  y0 = y;

#ifdef DEBUG
  cout << "-> Cargando: " << path << endl;
#endif

  //cargamos la imagen
  imagen = IMG_Load( path );
  if( imagen == NULL ){
    cerr << "Error: " << SDL_GetError() << endl;
    exit( 1 );
  }

  if( !alpha ){
    // convertimos a formato pantalla
    SDL_Surface *tmp = imagen;
    imagen = SDL_DisplayFormat( tmp );
    SDL_FreeSurface( tmp );

    if( imagen == NULL ){
      cerr << "Error: " << SDL_GetError() << endl;
      exit( 1 );
    }

    // calculamos el color transparente
    colorkey = SDL_MapRGB( imagen->format, r, g, b );

    // lo establecemos como color transparente
    SDL_SetColorKey( imagen, CK_FLAGS, colorkey );
  }

  /* obtenemos la imagen invertida utilizada en el mayor de los casos para 
     las imagenes de vuelta */
  imagen_invertida = invertir_imagen( imagen );
  if( imagen_invertida == NULL ){
    cerr << "No se pudo invertir la imagen: " << SDL_GetError() << endl;
    exit( 1 );
  }

  // el ancho de una imagen es el total entre el numero de columnas
  w = imagen->w / columnas;
  // el alto de una imagen es el total entre el numero de filas
  h = imagen->h / filas;

#ifdef DEBUG
  cout << "Imagen::Imagen()" << endl;
#endif
}

// liberamos los recursos
Imagen::~Imagen(){
  SDL_FreeSurface( imagen );
  SDL_FreeSurface( imagen_invertida );

#ifndef DEBUG
  cout << "Imagen::~Imagen()" << endl;
#endif
}

void Imagen::dibujar( SDL_Surface *superficie, int rejilla, int x, int y, int flip ){
  SDL_Rect destino;
  destino.x = x - x0;
  destino.y = y - y0;
  destino.w = 0;  // no se usa
  destino.h = 0;  // no se usa

  // comprovamos que el numero de imagen indicado sea el correcto
  if( rejilla < 0 || rejilla > ( filas * columnas ) ){
    cerr << "imagen::dibujar = No existe el cuadro: " << rejilla << endl;
    return;
  }

  SDL_Rect origen;
  /* separaciones de pixeles dentro de las rejillas para observar bien donde
     empieza una imagen y donde termina la otra */
  origen.w = w - SP_W;
  origen.h = h - SP_H;

  // seleccionamos cual de las imagenes es la que vamos a dibujar
  switch( flip ) {

  case 1:
    // calculo de la posicion de la imagen adentro de la rejilla
    origen.x = ( ( rejilla % columnas ) * w ) + SP_W;
    origen.y = ( ( rejilla / columnas ) * h ) + SP_H;

    SDL_BlitSurface( imagen, &origen, superficie, &destino );
    break;
 
  case -1:
    // calculo de la posicion de la imagen dentro de la regilla invertida
    origen.x = ( ( columnas -1 ) - ( rejilla % columnas ) ) * w;
    origen.y = ( rejilla / columnas ) * h + SP_H;

    // copiamos la imagen en la superficie
    SDL_BlitSurface( imagen_invertida, &origen, superficie, &destino );
    break;

  default:
    cerr << "Imagen::dibujar ERR : Caso no valido : Imagen invertida o no"  << endl;
    break;
  }  // fin switch
}

// devuelve la posición con respecto a la horizontal de la imagen
int Imagen::get_x() { return x0; }

// devuelve la posición con respecto a la vertical de la imagen
int Imagen::get_y() { return y0; }

// devuelve la anchura de un cuadro de la rejilla
int Imagen::get_w() { return w; }

// devuelve la altura de un cuadro de la rejilla
int Imagen::get_h() { return h; }

// devuelve el numero de cuadros de la rejilla de la imagen
int Imagen::get_frames() { return columnas * filas; }

SDL_Surface *Imagen::invertir_imagen( SDL_Surface *imagen ){
  SDL_Rect origen, destino;

  // Origen -> ancho una linea. Comienzo de copia por el principio
  origen.x = 0;
  origen.y = 0;
  origen.w = 1;
  origen.h = imagen->h;

  /* Destino -> ancho una linea. Comienzo de "pegado" por el final, 
     para lograr la invercion */
  destino.x = imagen->w;
  destino.y = 0;
  destino.w = 1;
  destino.h = imagen->h;

  SDL_Surface *invertida;

  // pasamos imagen a formato de pantalla
  invertida = SDL_DisplayFormat( imagen );

  if( invertida == NULL ){
    cerr << "No podemos convertir la imagen al formato de pantalla" << endl;
    return NULL;
  }

  // preparamos el rectangulo nuevo vacio del color transparente
  SDL_FillRect( invertida, NULL, colorkey );

  // copiamos linea vertical a linea vertical, inversamente
  for( int cont = 0; cont < imagen->w; cont++ ){
    SDL_BlitSurface( imagen, &origen, invertida, &destino );

    origen.x = origen.x + 1;
    destino.x = destino.x - 1;
  }

  return invertida;
}
