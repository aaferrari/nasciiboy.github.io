#include "regexp4.h"
#include <stdlib.h>
#include <stdio.h>

static char *data = NULL;
static int   data_len = 0;

void load_data( const char* file_name ){
  FILE* f;
  f = fopen(file_name, "rb");
  if (!f) {
    fprintf( stderr, "Cannot open '%s'!\n", file_name);
    exit( 1 );
  }

  fseek(f, 0, SEEK_END);
  data_len = ftell(f);
  fseek(f, 0, SEEK_SET);

  data = (char*)malloc(data_len + 1);
  if (!data) {
    fprintf( stderr, "Cannot allocate memory!\n" );
    fclose(f);
    exit( 1 );
  }

  data[data_len] = '\0';
  fread(data, data_len, 1, f);
  fclose(f);
}


int main( int argc, char *argv[] ){
  if( argc < 2 ){
    fprintf( stderr, "emailtor: wrong args");
    return 1;
  }

  load_data( argv[ 1 ] );

  char buff[1024];
  regexp4( data, "<([_A-Za-z0-9:-]+(:.[_A-Za-z0-9:-]+)*):@([A-Za-z0-9]+)(:.[A-Za-z0-9]+)*>", data_len );
  for( int i = 1; i <= totCatch(); i++ ){
    printf( "%s\n", cpyCatch( buff, i ) );
  }

  if( data ) free( data );
  return 0;
}
