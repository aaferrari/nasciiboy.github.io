
#ifndef _PAUSE_H
#define _PAUSE_H


bool pause_init(int retmode);
void pause_tick(void);

#endif
