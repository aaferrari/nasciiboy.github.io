// Listado: Enemigo_gok.cpp
// Implementación de la clase Enemigo_gok
#include <iostream>

#include "Enemigo_gok.h"
#include "Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Enemigo_gok::Enemigo_gok( enum tipo_participantes tipo, Juego *juego, 
                          int x, int y, int direccion ) :
  Enemigo( juego, x, y, direccion, tipo ){
  // según el tipo de enemigo que estemos creando
  if( tipo == TIPO_ENEMIGO_GOK ){
    imagen = juego->universo->galeria->get_imagen( Galeria::ENEMIGO_GOK );
    // creamos las animaciones para el personaje en particular
    animaciones[APPEAR] = new Secuencia( "4,5" , 5 );
    animaciones[PARADO] = new Secuencia( "0" , 5 );
    animaciones[CAMINAR] = new Secuencia( "0,5" , 5 );
    animaciones[GOLPEAR] = new Secuencia( "0,1,2,3", 10 );
    animaciones[MORIR] = new Secuencia( "4,5", 10 );

    SDL_Rect rect_principal[] = { { 10, 30, 80, 70 } };
    for( int i = 0; i < 1; i++ )
	add_rect(rect_principal[ i ] );
  } else
    cerr << "Enemigo_gok::Enemigo_gok() -> Enemigo no contenplado" << endl;

  // estado inicial para los enemigos
  estado = APPEAR;

#ifndef DEBUG
  cout << "Enemigo_gok::Enemigo_gok()" << endl;
#endif
}

Enemigo_gok::~Enemigo_gok(){
#ifdef DEBUG    
    cout << "Enemigo_gok::~Enemigo_gok" << endl;
#endif
}

void Enemigo_gok::actualizar(){
  switch( estado ) {

  case MORIR: 
    // cuando la secuencia alcance el final se cambia de estado
    if( animaciones[ estado ]->avanzar() )
      estado = ELIMINAR;
    break;

  case ELIMINAR: break;

  case PARADO: if( posicion != 0 ) estado = CAMINAR; break;

  case CAMINAR:
    if( animaciones[ estado ]->avanzar() && posicion == 0 ) estado = PARADO;
    if( posicion  < 0 ) direccion = 1;
    else if( posicion > 0 ) direccion = -1;
    // Hacemos que gire si se acaba el suelo
    if( pisa_el_suelo( x + direccion * 20, y ) )
      mover_sobre_x(  direccion * 2 );
    if( abs( posicion ) == 1 ) estado = GOLPEAR;
    break;

  case GOLPEAR:
    if( animaciones[ estado ]->avanzar() && abs( posicion ) != 1 ) estado = CAMINAR;
    if( posicion  < 0 ) direccion = 1;
    else if( posicion > 0 ) direccion = -1;
    break;

  case APPEAR :
    if( pisa_el_suelo() ){ estado = PARADO; break; }
    animaciones[ estado ]->avanzar();

    // si llega al limite vertical muere
    if( y > NIV_HEIGHT ) estado = ELIMINAR;

    // tiene que llegar al suelo
    if( !pisa_el_suelo() ){
      velocidad_salto += 0.1;
      y += altura( (int) velocidad_salto );
      mover_sobre_x( direccion );
    }
    break;

  default: break;
  }
}
