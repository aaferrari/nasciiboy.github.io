// Listado: Intro.h
// Esta clase controla los aspectos relevantes al Menú de la aplicación
#ifndef INTRO_H
#define INTRO_H

#include <SDL/SDL.h>

#include "Interfaz.h"
#include "Common_Const.h"

class Texto;
class Universo;
class Teclado;
class Control_Movimiento;

const int NUM_S = 2;

class Intro: public Interfaz {
 public:
  Intro( Universo *universo );  // constructor
  ~Intro();                     // destructor

  // funciones heradas de Interfaz operativa de la clase
  void reiniciar ();
  void actualizar ();
  void dibujar ();

 private:
  Control_Movimiento *gnu;     // para el titulo del juego
  Control_Movimiento *sdl;     // para el titulo del juego
  Control_Movimiento *i;       // para el titulo del juego

  void get_titulo();           // crea los títulos del juego
  void get_strings();          // crea las cadenas que se almacenarán en cadena_opciones

  int delay;                   // ciclos que se mantine la intro
  Uint32 IN_BG_COLOR;          // color de fondo para el menu
  Teclado *teclado;            // controla el dispositivo de entrada
  Texto *end_chars[ NUM_S ];
};

#endif
