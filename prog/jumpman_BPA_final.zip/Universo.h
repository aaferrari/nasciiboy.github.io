// Listado: Universo.h
/* Nos permite cohesionar todas las clases de la aplicación y
   nos permite llevar un control global sobre la misma */
#ifndef _UNIVERSO_H
#define _UNIVERSO_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

#include "Teclado.h"
#include "Interfaz.h"
#include "sdl_init.h"

class Galeria;
class Juego;
class Editor;
class Menu;
class Intro;
class End;

class Universo {
 public:
  Universo();              // constructor
  ~Universo();             // destructor 

  void terminar();         // finaliza el juego
  void bucle_principal();  // proporciona la "reproducción continua"

  // nos permite el cambio entre "opciones" del juego
  void set_interfaz( Interfaz::escenas nueva );

  // dibuja un rectángulo en pantalla
  void dibujar_rect( int x, int y, int w, int h, Uint32 color = 0 );

  // si se modifico nivel, permite acceder a juego->nivel desde apuntador
  void nivel_modificado();

  // nos permite acceder al nivel actual para modificarlo
  int modificar_nivel();

  Teclado teclado;        // controla el dispositivo de entrada
  Galeria *galeria;       // almacena todas las imágenes necesarias
  SDL_Surface *pantalla;  // superficie principal del videojuego 

 private:
  SDL_Surface *icon;      // icono de la aplicacion
  Interfaz *actual;       // escena en la que estamos
  Juego *juego;           // pantalla del juego
  Editor *editor;         // pantalla del juego
  Menu *menu;             // pantalla del juego
  Intro *intro;             // pantalla del juego
  End *end;             // pantalla del juego
  bool salir;             // variable que modificamos cuando queremos salir de la aplicación
  Uint32 colorbg;         // color que para limpiar ventana

  int get_evento();       // estudia los eventos en un momento dado
  void fullscreen();      // alterna el modo de video
  int sincronizar_fps();  // lleva el control del tiempo
};

#endif 
