// Listado: Enemigo_bok.cpp
// Implementación de la clase Enemigo_bok
#include <iostream>

#include "Enemigo_bok.h"
#include "Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Enemigo_bok::Enemigo_bok( enum tipo_participantes tipo, Juego *juego, 
		          int x, int y, int direccion ) :
  Enemigo( juego, x, y, direccion, tipo ) {
  // según el tipo de enemigo que estemos creando
  if( tipo == TIPO_ENEMIGO_BOK ){
    imagen = juego->universo->galeria->get_imagen( Galeria::ENEMIGO_BOK );
    // creamos las animaciones para el personaje en particular
    animaciones[APPEAR] = new Secuencia( "0,1,2,3" , 15 );
    animaciones[CAMINAR] = new Secuencia( "4,5,6", 10 );
    animaciones[MORIR] = new Secuencia( "7,8", 10 );

    SDL_Rect rect_principal[] = { { 35, 62, 30, 33 } };
    for( int i = 0; i < 1; i++ )
	add_rect( rect_principal[ i ] );
  } else
    cout << "Enemigo_bok::Enemigo_bok() -> Enemigo no contenplado" << endl;

  // estado inicial para los enemigos
  estado = APPEAR;

#ifndef DEBUG
  cout << "Enemigo_bok::Enemigo_bok()" << endl;
#endif
}

Enemigo_bok::~Enemigo_bok(){
#ifdef DEBUG    
    cout << "Enemigo_bok::~Enemigo_bok" << endl;
#endif
}

void Enemigo_bok::actualizar(){
  switch( estado ) { 

  case MORIR :
    // cuando la secuencia alcance el final se cambia de estado
    if( animaciones[ estado ]->avanzar() )
      estado = ELIMINAR;
    break;

  case ELIMINAR : break;

  case CAMINAR :
    // hacemos avanzar la animación
    animaciones[ estado ]->avanzar();
    // si llega al limite vertical muere
    if( y > NIV_HEIGHT ){ estado = ELIMINAR; }

    if( pisa_el_suelo() ){
      // Hacemos que gire si se acaba el suelo
      if( !pisa_el_suelo( x + direccion * 5, y ) )
        direccion *= -1;

      if( !mover_sobre_x( direccion ) ) direccion *= -1;
    }
    break;

  case APPEAR :
    if( pisa_el_suelo() ){ estado = CAMINAR; break; }
    animaciones[ estado ]->avanzar();

    // si llega al limite vertical muere
    if( y > NIV_HEIGHT ) estado = ELIMINAR;

    // tiene que llegar al suelo
    if( !pisa_el_suelo() ){
      velocidad_salto += 0.1;
      y += altura( (int)velocidad_salto );
      mover_sobre_x( direccion );
    }
    break;

  default: break;
  } // fin switch
}
