
#ifndef _ISLAND_H
#define _ISLAND_H

bool island_init(int survives);
void island_tick();


#endif
