// Listado: Colision.cpp
// Implementación de funciones dedicadas a la detección de colisiones
#include <SDL/SDL.h>
#include <iostream>
#include "Participante.h"
#include "Colision.h"

using namespace std;

bool colision( Participante *uno, Participante *otro ){
  int w1, h1, x1, y1,  // w = ancho, h = alto
      w2, h2, x2, y2;  // x = punto de partida x, y = punto de partida y

  // todos los rectángulos del primer personaje
  for( unsigned int i = 0; i < uno->rectangulos.size(); i++ ){
    w1 = uno->rectangulos[ i ].w;
    h1 = uno->rectangulos[ i ].h;
    x1 = uno->rectangulos[ i ].x + uno->get_x();
    y1 = uno->rectangulos[ i ].y + uno->get_y();

    // todos los rectángulos del segundo personaje
    for( unsigned int j = 0; j < otro->rectangulos.size(); j++ ){
      w2 = otro->rectangulos[ j ].w;
      h2 = otro->rectangulos[ j ].h;
      x2 = otro->rectangulos[ j ].x + otro->get_x();
      y2 = otro->rectangulos[ j ].y + otro->get_y();

      // Si existe colisión entre alguno de los rectángulos paramos los bucles
      if( ( ( x1 + w1 ) > x2 ) &&
	  ( ( y1 + h1 ) > y2 ) &&
	  ( ( x2 + w2 ) > x1 ) &&
	  ( ( y2 + h2 ) > y1 ) ) 
	return true;
    }
  }

  return false;
}
