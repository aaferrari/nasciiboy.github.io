// Listado: Galeria.cpp
// Implementación de la clase galería del videojuego
#include <iostream>

#include "Galeria.h"
#include "Imagen.h"
#include "Fuente.h"
#include "Musica.h"
#include "Sonido.h"
#include "Common_Const.h"

using namespace std;

static bool colorkey = false;
static int ajuste_x = 50;
static int ajuste_y = 90;

Galeria::Galeria(){
  /* cargamos las rejillas en la galería para las animaciones
     y las imágenes fijas */
  imagenes[HERO] = new Imagen( IMG_HERO, 6, 11, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ENEMIGO_AOK] = new Imagen( IMG_AOK, 1, 5, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ENEMIGO_BOK] = new Imagen( IMG_BOK, 1, 9, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ENEMIGO_DOK] = new Imagen( IMG_DOK, 1, 5, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ENEMIGO_FOK] = new Imagen( IMG_FOK, 1, 5, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ENEMIGO_GOK] = new Imagen( IMG_GOK, 1, 6, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ENEMIGO_LOK] = new Imagen( IMG_LOK, 1, 7, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ENEMIGO_ROK] = new Imagen( IMG_ROK, 1, 5, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[FIRE_LOK] = new Imagen( IMG_FIRE_LOK, 1, 7, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[KEY] = new Imagen( IMG_KEY, 1, 5, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ITEM_POWER] = new Imagen( IMG_POWER, 1, 5, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[ITEM_LIFE] = new Imagen( IMG_LIFE, 1, 10, ajuste_x, ajuste_y, colorkey, 0, 0, 255 );
  imagenes[TILES] = new Imagen( IMG_TILES, 32, 8, 0, 0, colorkey, 0, 255, 0 );
  imagenes[TILES_CH] = new Imagen( IMG_TILES_CH, 32, 8, 0, 0, colorkey, 0, 0, 255 );
  imagenes[TILES_ED] = new Imagen( IMG_TILES_ED, 2, 8, 0, 0, colorkey, 0, 255, 0 );
  imagenes[TILES_BK] = new Imagen( IMG_TILES_BK, 32, 8, 0, 0, colorkey, 0, 255, 0 );
  imagenes[INBO] = new Imagen( IMG_INBO, 1, 4, 0, 0, colorkey, 0, 255, 0 );
  imagenes[INTRO_GNU] = new Imagen( IMG_GNU, 1, 1, 0, 0, false, 0, 255, 0 );
  imagenes[INTRO_SDL] = new Imagen( IMG_SDL, 1, 1, 0, 0, false, 0, 255, 0 );
  imagenes[INTRO_I] = new Imagen( IMG_I, 1, 1, 0, 0, false, 0, 255, 0 );

  // cargamos las fuentes en la galería
  fuentes[FUENTE_INTRO] = new Fuente( 30, "data/font/FreeMonoBold.ttf" );
  fuentes[FUENTE_MENU] = new Fuente( 30 );
  fuentes[FUENTE_MARCADOR] = new Fuente( 20 );

  // cargamos la música de la galería
  musicas[MUSICA_MENU] = new Musica( MUS_MENU );
  musicas[MUSICA_EDITOR] = new Musica( MUS_EDITOR );
  musicas[MUSICA_JUEGO] = new Musica( MUS_JUEGO );
  musicas[MUSICA_END] = new Musica( MUS_END );

  // cargamos los sonidos de efectos
  sonidos[COGE_ITEM] = new Sonido( SFX_ITEM );
  sonidos[MATA_MALO] = new Sonido( SFX_MALO );    
  sonidos[PASA_NIVEL] = new Sonido( SFX_NIVEL );  
  sonidos[EFECTO_MENU] = new Sonido( SFX_MENU );
  sonidos[MUERE_BUENO] = new Sonido( SFX_BUENO );

#ifdef DEBUG
  cout << "Galeria::Galeria()" << endl;
#endif
}

Galeria::~Galeria(){
  // liberamos reqursos de la galería
  delete imagenes[ HERO ];
  delete imagenes[ TILES ];
  delete imagenes[ TILES_ED ];
  delete imagenes[ TILES_CH ];
  delete imagenes[ TILES_BK ];
  delete imagenes[ INTRO_GNU ];
  delete imagenes[ INTRO_SDL ];
  delete imagenes[ INTRO_I ];
  delete imagenes[ ENEMIGO_AOK ];
  delete imagenes[ ENEMIGO_BOK ];
  delete imagenes[ ENEMIGO_DOK ];
  delete imagenes[ ENEMIGO_FOK ];
  delete imagenes[ ENEMIGO_GOK ];
  delete imagenes[ ENEMIGO_LOK ];
  delete imagenes[ ENEMIGO_ROK ];
  delete imagenes[ FIRE_LOK ];
  delete imagenes[ KEY ];
  delete imagenes[ INBO ];
  delete imagenes[ ITEM_POWER ];
  delete imagenes[ ITEM_LIFE ];

  delete fuentes[ FUENTE_MENU ];
  delete fuentes[ FUENTE_MARCADOR ];
  delete fuentes[ FUENTE_INTRO ];

  delete musicas[ MUSICA_MENU ];
  delete musicas[ MUSICA_JUEGO ];
  delete musicas[ MUSICA_EDITOR ];
  delete musicas[ MUSICA_END ];

  delete sonidos[ COGE_ITEM ];
  delete sonidos[ MATA_MALO ];
  delete sonidos[ PASA_NIVEL ];
  delete sonidos[ EFECTO_MENU ];
  delete sonidos[ MUERE_BUENO ];

#ifdef DEBUG
  cout << "Galeria::~Galeria()" << endl;
#endif
}

// devolvemos la imagen solicitada
Imagen *Galeria::get_imagen( codigo_imagen cod_ima ) { return imagenes[ cod_ima ]; }

// devolvemos la fuente solicitada
Fuente *Galeria::get_fuente( codigo_fuente indice ) { return fuentes[ indice ]; }

// devolvemos la música solicitada
Musica *Galeria::get_musica( codigo_musica cod_music ) { return musicas[ cod_music ]; }

// devolvemos el sonido solicitado
Sonido *Galeria::get_sonido( codigo_sonido cod_sonido ) { return sonidos[ cod_sonido ]; }
