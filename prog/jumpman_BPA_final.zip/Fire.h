// Listado: Fire.h
/* Clase Fire, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef FIRE_LOK_H
#define FIRE_LOK_H

#include "Enemigo.h"

class Juego;

class Fire : public Enemigo {
 public:
  Fire( enum tipo_participantes tipo, Juego *juego,
        int x, int y, int direccion = 1 );
  virtual ~Fire();

  virtual void actualizar();
};

#endif
