// Listado: Musica.h
// Clase para facilitar el trabajo con la musica
#ifndef MUSICA_H
#define MUSICA_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

class Musica {
 public:
  Musica( const char *path );
  ~Musica();

  void reproducir();
  void pausar();

 private:
  Mix_Music *bso;
};

#endif
