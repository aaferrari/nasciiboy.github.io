// Listado: Texto.h
/* Con esta clase controlamos los textos con los que va a 
   trabajar la aplicación */
#ifndef _TEXTO_H
#define _TEXTO_H

#include <SDL/SDL.h>

const SDL_Color default_color = { 255, 255, 255, 255 };

class Fuente;

class Texto {
 public:
  Texto( Fuente *fuente, int x, int y, 
	 const char *cadena );           // constructor
  ~Texto();                              // destructor

  void dibujar( SDL_Surface *pantalla, SDL_Color color = default_color ); // llama a fuente->palabra
  void actualizar();                     // sin accion asignada

 private:
  int x, y;                              // coordenadas destino
  Fuente *fuente;                        // almacena fuente
  char *texto;                           // almacena texto
};

#endif
