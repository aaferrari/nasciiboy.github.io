// Listado: Fuente.h
/* Esta clase controla la impresión de textos en pantalla
   mediantes fuentes ttf o tira de imágenes */
#ifndef FUENTE_H
#define FUENTE_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>

#include "Common_Const.h"

class Fuente {
 public:
  // constructores
  Fuente( int tamano = TAM_FONT, const char *path = PRE_FONT );
  ~Fuente();

  // funciones para escribir utilizando una fuente ttf
  void palabra( SDL_Surface *superficie, const char *palabra = "o_o!",
		int x = 0, int y = 0, SDL_Color color = COLOR_FONT );
  void frase( SDL_Surface *superficie, const char *frase = "o_o!",
	      int x = 0, int y = 0, SDL_Color color = COLOR_FONT );

 private:
  TTF_Font *fuente;     // para almacenar la fuente TTF
  int puntos;           // tamaño de la fuente
  SDL_Surface *imagen;  // dónde almacenar la imagen resultante a mostrar
};

#endif
