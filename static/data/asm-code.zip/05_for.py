V = [2, 4, 6, 8, 10]
n = 5
suma = 0

for i in range(n):  # i = [0..N-1]
  suma = suma + V[i]
