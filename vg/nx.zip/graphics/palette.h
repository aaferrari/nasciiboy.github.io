
#ifndef _PALETTE_H
#define _PALETTE_H





#endif
