// Listado: Enemigo_bok.h
/* Clase Enemigo_bok, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef ENEMIGO_BOK_H
#define ENEMIGO_BOK_H

#include "Enemigo.h"

class Juego;

class Enemigo_bok : public Enemigo {
 public:
  Enemigo_bok( enum tipo_participantes tipo, Juego *juego,
	       int x, int y, int direccion = 1 );
  virtual ~Enemigo_bok();

  virtual void actualizar();
};

#endif
