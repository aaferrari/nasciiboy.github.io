// Listado: End.cpp
// Implementación de la clase End
#include <iostream>

#include "End.h"

using namespace std;

End::End( Universo *universo ) : Interfaz( universo ){
  // el dispositivo de entrada nos lo da el entorno del juego
  teclado = &( universo->teclado );
  
  END_BG_COLOR = SDL_MapRGB( universo->pantalla->format, 100, 100, 250 );
  get_titulo();     // creamos los títulos
  get_strings();
  reiniciar();      // inicio End

#ifdef DEBUG
  cout << "End::End()" << endl;
#endif
}

End::~End(){
  // liberamos memoria
  delete inbo;

  for( int i = 0; i < NUM_STRINGS; i ++ )
    delete end_chars[ i ];
  
#ifdef DEBUG
  cout << "End::~End()" << endl;
#endif
}

void End::get_titulo(){
  // creamos los títulos animados
  inbo = 
    new Control_Movimiento( universo->galeria->get_imagen( Galeria::HERO ), \
			    0, 0, 0, 2 );
}

void End::get_strings(){
  // crea las cadenas que mostraremos como opciones
  char textos[][ 40 ] = { { "GRACIAS POR TESTEAR" }, { "este fue el primer juego" } };

  // cargamos la fuente
  Fuente *fuente = universo->galeria->get_fuente( Galeria::FUENTE_INTRO );

  end_chars[ 0 ] = new Texto( fuente, 250, 300, textos[ 0 ] );
  end_chars[ 1 ] = new Texto( fuente, 100, 350, textos[ 1 ] );
}

void End::reiniciar(){
  // hacemos sonar la música
  universo->galeria->get_musica( Galeria::MUSICA_END )->pausar();   
  universo->galeria->get_musica( Galeria::MUSICA_END )->reproducir();

  /* colocamos cada parte del título en su lugar desde una posición 
     de origen hasta la posición final */
  inbo->mover_inmediatamente( 100, -250 );
  inbo->mover( 150, 250 );
}

void End::actualizar(){
  inbo->actualizar();     // actualizamos los títulos

  if( teclado->pulso( OK ) )
    universo->set_interfaz( ESCENA_INTRO );
}

void End::dibujar(){
  // dibujamos el fondo con el color anaranjado
  SDL_FillRect( universo->pantalla, NULL, END_BG_COLOR );

  // dibujamos los títulos
  inbo->dibujar( universo->pantalla );

  // dibujamos las 3 cadenas de opciones
  for( int i = 0; i < NUM_STRINGS; i ++ )
    end_chars[ i ]->dibujar( universo->pantalla );

  // actualizamos la pantalla del entorno
  SDL_Flip( universo->pantalla );
}
