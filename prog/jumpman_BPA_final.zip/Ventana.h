// Listado: Ventana.h
// Esta clase nos permite navegar por las superficies de los niveles
#ifndef _VENTANA_H
#define _VENTANA_H

#include <SDL/SDL.h>

class Ventana {
 public:
  Ventana( int filas, int columnas );      // constructor
  ~Ventana();                              // destructor

  void actualizar();                       // realiza movimiento progresivo de foco
  void set_destino( int x, int y );        // para determinar coordenada de foco destino
  void get_destino( int *x, int *y );      // optener cordenada destinno
  void set_actual( int x = 0, int y = 0 ); // establecer de inmediato el foco
  void get_actual( int *x, int *y );       // consultora
  int get_x();                             // consultora
  int get_y();                             // consultora

 private:
  int
    x, y,                             // posicion actual de ventana
    x_final, y_final,                 // posicion a llegar
    limite_x, limite_y;               // limite de foco

  void limitar_movimiento();          // evita salir del nivel
};

#endif
