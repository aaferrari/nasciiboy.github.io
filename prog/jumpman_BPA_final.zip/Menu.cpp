// Listado: Menu.cpp
// Implementación de la clase Menu
#include <iostream>

#include "Menu.h"
#include "Universo.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Sonido.h"
#include "Teclado.h"
#include "Control_Movimiento.h"
#include "Fuente.h" 
#include "Texto.h"
#include "Musica.h"
#include "Secuencia.h"

using namespace std;

const int cursor_x = 400;
const int cursor_y = 307;

Menu::Menu( Universo *universo ) : Interfaz( universo ){
  // el dispositivo de entrada nos lo da el entorno del juego
  teclado = &( universo->teclado );
  
  // cargamos el cursor de selección
  cursor = new Control_Movimiento( universo->galeria->get_imagen( Galeria::TILES_ED ),
				   1, cursor_x, cursor_y );
  inbo = universo->galeria->get_imagen( Galeria::INBO );
  secuencia = new Secuencia( "0,1,2", 10 );
  opcion = 0;

  //  MN_BG_COLOR = SDL_MapRGB( universo->pantalla->format, MN_BG_R, MN_BG_G, MN_BG_B );
  MN_BG_COLOR = SDL_MapRGB( universo->pantalla->format, 0, 0, 0 );
  get_strings();    // creo las cadenas de las opciones
  reiniciar();      // inicio el Menu

  panel_visible = false;


#ifdef DEBUG
  cout << "Menu::Menu()" << endl;
#endif
}

Menu::~Menu(){
  // liberamos memoria
  delete cursor;
  delete secuencia;
  
  // tamabién de las cadenas

  for( int i = 0; i < NUM_OPCIONES; i ++ )
    delete opciones[ i ];

#ifdef DEBUG
  cout << "Menu::~Menu()" << endl;
#endif
}

void Menu::get_strings(){
  // crea las cadenas que mostraremos como opciones
  char textos[][ 15 ] = { { "J U G A R" }, { "E D IT A R" }, { "S A L IR" } };

  // cargamos la fuente
  Fuente *fuente = universo->galeria->get_fuente( Galeria::FUENTE_MENU );

  // la amacenamos en el vector de tipo Texto
  for( int i = 0; i < NUM_OPCIONES; i++ )
    opciones[ i ] = new Texto( fuente, 450, 300 + i * 50, textos[ i ] );
}

void Menu::reiniciar(){
  // hacemos sonar la música
  universo->galeria->get_musica( Galeria::MUSICA_MENU )->pausar();   
  universo->galeria->get_musica( Galeria::MUSICA_MENU )->reproducir();
  secuencia->reiniciar();

  panel_visible = false;
  opcion = 0;
  cursor->mover_inmediatamente( cursor_x, cursor_y + 50 * opcion );
}

void Menu::actualizar(){
  static int delay = 0;   // variable con "memoria", consulta el teclado cada 30 ciclos

  cursor->actualizar();   // actualizamos el cursor seleccionador

  secuencia->avanzar();

  // si el panel no es visible al pulsar la tecla OK lo mostramos
  if( panel_visible == false ){
    if( teclado->pulso( OK ) && delay == 0 ){
      panel_visible = true;
      delay = 30;
    }
  }

  // cuando el panel es visible actualizamos las opciones
  if( panel_visible == true ){
    /* si pulsamos abajo y no estamos en la última( controlamos 
       no ir excesivamente rápido ) */
    if( teclado->pulso( DOWN ) && opcion < 2 && delay == 0 ){
      delay = 30;                              // retardo de 30 ciclos
      opcion++;                                // bajamos -> opcion = opcion + 1          
      cursor->mover( cursor_x, cursor_y + 50 * opcion ); // movemos el cursor

      // reproducimos un efecto de sonido
      universo->galeria->sonidos[ Galeria::EFECTO_MENU ]->reproducir();
    }

    // si pulsamos arriba y no estamos en la primera opción
    if( teclado->pulso( UP ) && opcion > 0 && delay == 0 ){
      delay = 30;                              // retardo de 30 ciclos
      opcion--;                                // subimos -> opcion = opcion - 1
      cursor->mover( cursor_x, cursor_y + 50 * opcion ); // movemos el cursor

      // reproducimos un efecto de sonido
      universo->galeria->sonidos[ Galeria::EFECTO_MENU ]->reproducir();
    }

    // si pulsamos arriba y estamos en la primera opción
    if( teclado->pulso( UP ) && opcion == 0 && delay == 0 ){
      delay = 30;                              // retardo de 30 ciclos
      opcion = 2;                              // subimos -> opcion = opcion - 1
      cursor->mover( cursor_x, cursor_y + 50 * opcion ); // movemos el cursor

      // reproducimos un efecto de sonido
      universo->galeria->sonidos[ Galeria::EFECTO_MENU ]->reproducir();
    }

    // si pulsamos abajo y estamos en la ultima opción
    if( teclado->pulso( DOWN ) && opcion == 2 && delay == 0 ){
      delay = 30;                              // retardo de 30 ciclos
      opcion = 0;                              // subimos -> opcion = opcion - 1
      cursor->mover( cursor_x, cursor_y + 50 * opcion ); // movemos el cursor

      // reproducimos un efecto de sonido
      universo->galeria->sonidos[ Galeria::EFECTO_MENU ]->reproducir();
    }

    // si regresamos se oculta el panel
    if( teclado->pulso( EXIT ) && delay == 0 ){
      panel_visible = false; delay = 30;
    }

    if( delay == 0 ){
      // si aceptamos
      if( teclado->pulso( OK ) ){ 
        // entramos en una opción determinada
        switch( opcion ){

          // jugar
        case 0: universo->set_interfaz( ESCENA_JUEGO ); break;
          // editar niveles
        case 1: universo->set_interfaz( ESCENA_EDITOR ); break;
          // salir de la aplicación
        case 2: universo->terminar(); break;
        }

      }
    }   // fin de opciones
  }     // fin panel_visible == true

  if( delay ) delay--; // reducimos el retardo
}

void Menu::dibujar(){
  // dibujamos un rectángulo de fondo con el color anaranjado
  SDL_FillRect( universo->pantalla, NULL, MN_BG_COLOR );

  if( panel_visible  )
    inbo->dibujar( universo->pantalla, secuencia->get_frame(), 20, 310 );
  else
    inbo->dibujar( universo->pantalla, 3, 180, 170 );

  if( panel_visible == true ){
    // dibujamos el cursor que selecciona una opción u otra
    cursor->dibujar( universo->pantalla );

      // dibujamos las 3 cadenas de opciones
      for( int i = 0; i < NUM_OPCIONES; i ++ )
	opciones[ i ]->dibujar( universo->pantalla );
  }

  // actualizamos la pantalla del entorno
  SDL_Flip( universo->pantalla );
}
