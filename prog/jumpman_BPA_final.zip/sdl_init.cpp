// Implementación de funciones auxiliares para la inicializacion y cierre de SDL
#include <iostream>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>

#include "sdl_init.h"

using namespace std;

// inicializa SDL con los parámetros predeterminados
int sdl_init( SDL_Surface **pantalla, SDL_Surface **icon,  const char *caption, \
	      int ancho, int alto, int bpp ){

  // iniciamos SDL
  if( SDL_Init( INIT_FLAGS ) < 0 ){
    cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
    return 1;
  }
  atexit( SDL_Quit );

  // Verificamos el soporte para el modo de video el modo de video    
  if( SDL_VideoModeOK( ancho, alto, bpp, WM_FLAGS ) == 0 ){
    cerr << "Modo de video no soportado: " << SDL_GetError() << endl;
    return 1;
  }

  // establecemos el icono y el titulo de la ventana
  *icon = IMG_Load( ICON );
  if( *icon == NULL ){
    cerr << "No se pudo establecer el icono: " << SDL_GetError() << endl;
    return 1;
  }
  SDL_WM_SetIcon( *icon, NULL );
  SDL_WM_SetCaption( caption, NULL );

  // establecemos el modo de video
  *pantalla = SDL_SetVideoMode( ancho, alto, bpp, WM_FLAGS );
  if( *pantalla == NULL ){
    cerr << "No se pudo establecer el modo de video: " << SDL_GetError() << endl;
    SDL_FreeSurface( *icon );
    return 1;
  }

  SDL_ShowCursor( SDL_DISABLE );  // ocultamos el cursor

  // inicializamos la librería SDL_Mixer
  if( Mix_OpenAudio( FREQ_MIX, FORMAT_MIX, CHANNEL_MIX, CHUNK_SIZE ) < 0 ){
    cerr << "Subsistema de Audio no disponible: " << Mix_GetError() << endl;
    return 1;
  }
  atexit( Mix_CloseAudio );       // al salir cierra el subsistema de audio
    
  return 0;
}

// Maneja los eventos de salida
int close_event( SDL_Surface **pantalla,SDL_Surface **icon ){
  // La misma variable para todas las llamadas
  static SDL_Event evento;

  // Bucle de control de los eventos de salida
  while( SDL_PollEvent( &evento ) ){
    if( evento.type == SDL_KEYDOWN ){
      if( evento.key.keysym.sym == CLOSE_APP ){
        SDL_FreeSurface( *icon ); 
	return 1;
      }
      if( evento.key.keysym.sym == WM_CHANGE ){
	// alterna entre pantalla completa y ventana
	if( SDL_WM_ToggleFullScreen( *pantalla ) != 1 )
	  cerr << "Error al Cambiar de modo: " << SDL_GetError() << endl;
      }
    }
    if( evento.type == SDL_QUIT ){
      SDL_FreeSurface( *icon );
      return 1;
    }
  } // fin Poll event

 return 0;
}
