// Listado: Fuente.cpp
// Implementación de la clase Fuente
#include <iostream>

#include "Fuente.h"

using namespace std;

// mediante fuente ttf
Fuente::Fuente( int tamano, const char *path ){
  // iniciamos la librería SDL_ttf
  if( TTF_Init() < 0 ){
    cerr << "No se puede iniciar SDL_ttf" << endl;
    exit( 1 );
  }
  atexit( TTF_Quit );  // al terminar cerramos SDL_ttf

  puntos = tamano;     // tamaño en puntos de la fuente
  imagen = NULL;

  // cargamos la fuente que queremos utilizar con un determinado tamaño
  fuente = TTF_OpenFont( path, tamano );

  if( fuente == NULL ){
    cerr << "No se puede abrir la fuente deseada" << endl;
    exit( 1 );
  }

#ifdef DEBUG
  cout << "Fuente::Fuente()" << endl;
#endif
}

Fuente::~Fuente(){ 
  SDL_FreeSurface( imagen );  // liberamos la superficie
  TTF_CloseFont( fuente );    // liberamos la fuente

#ifdef DEBUG
  cout << "Fuente::~Fuente()" << endl;
#endif
}


void Fuente::palabra( SDL_Surface *superficie, const char *palabra, \
		      int x, int y, SDL_Color color ){
  // renderizamos y almacenamos en una superficie
  imagen = TTF_RenderText_Solid( fuente, palabra, color );

  // convertimos la imagen obtenida a formato de pantalla
  SDL_Surface *tmp = imagen;
  imagen = SDL_DisplayFormat( tmp );
  SDL_FreeSurface( tmp );

  // colocamos en la pantalla principal en( x, y )
  SDL_Rect destino;
  destino.x = x;
  destino.y = y;
  destino.w = imagen->w;
  destino.h = imagen->h;

  SDL_BlitSurface( imagen, NULL, superficie, &destino );
}

/* construimos frases con fuentes ttf cuyo espacio no sea compatible
   con SDL_ttf */
void Fuente::frase( SDL_Surface *superficie, const char *frase, \
		    int x, int y, SDL_Color color ){
  int offset_x = 0;          // distancia entre una letra y la siguiente
  char *proximo, *frase_tmp; // para manejo de cadena sin desperdicio de memoria

  frase_tmp = new char[ strlen( frase ) + 1 ];
  if( frase_tmp == NULL ){
    cerr << "Fuente: Memoria para frase_tmp no asignada." << endl;
    exit( 1 );
  }
  strcpy( frase_tmp, frase );

  for( proximo = strtok( frase_tmp, " \0" ); proximo; ){
    /* no utilizamos la función anterior para facilitar el 
       cálculo del offset. Renderizamos y almacenamos en una superficie */
    imagen = TTF_RenderText_Solid( fuente, proximo, color );

    // convertimos a formato de pantalla
    SDL_Surface *tmp = imagen;
    imagen = SDL_DisplayFormat( tmp );
    SDL_FreeSurface( tmp );

    // colocamos en la pantalla principal en( x, y )
    SDL_Rect destino;
    destino.x = x + offset_x;
    destino.y = y;
    destino.w = imagen->w;
    destino.h = imagen->h;

    // calculamos el offset entre letras
    offset_x += imagen->w + puntos / 3;

    SDL_BlitSurface( imagen, NULL, superficie, &destino );
    proximo = strtok( NULL, " \0" );
  }

  delete [] frase_tmp;
}
