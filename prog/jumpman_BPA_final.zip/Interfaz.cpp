// Listado: Interfaz.cpp
// Implementación de la clase interfaz
#include <iostream>

#include "Interfaz.h"
#include "Universo.h"

using namespace std;

Interfaz::Interfaz( Universo *universo ){
#ifdef DEBUG
  cout << "Interfaz::Interfaz()" << endl;
#endif

  this->universo = universo;
}

Interfaz::~Interfaz(){
#ifdef DEBUG
  cout << "Interfaz::~Interfaz()" << endl;
#endif
}
