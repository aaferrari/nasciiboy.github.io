// Listado: Participante.h
/* Clase madre que proporciona una interfaz para los participantes
   que componen el juego */
#ifndef _PARTICIPANTE_H
#define _PARTICIPANTE_H

#include <map>
#include <SDL/SDL.h>

#include "Juego.h"
#include "Nivel.h"
#include "Secuencia.h"
#include "Imagen.h"

class Participante {
 public:
  Participante( Juego *juego, int x, int y, int direccion = 1 );  // constructor
  virtual ~Participante();                                        // destructor

  // tipos de participantes
  enum tipo_participantes { TIPO_HERO, TIPO_ENEMIGO_AOK, TIPO_ENEMIGO_BOK, TIPO_ENEMIGO_DOK, 
                            TIPO_ENEMIGO_FOK, TIPO_ENEMIGO_GOK, TIPO_ENEMIGO_LOK,
                            TIPO_ENEMIGO_ROK, TIPO_KEY,
			    TIPO_ITEM_POWER, TIPO_ITEM_LIFE,
                            TIPO_FIRE_LOK };
  // estados posibles de los participantes
  enum estados { APPEAR, PARADO, CAMINAR, SALTAR, MORIR, ELIMINAR, GOLPEAR, SUPER,
                 DAMAGE, FLY };

  int get_x();                                           // consultora 
  int get_y();                                           // consultora 
  estados get_estado() { return estado; };               // consultora
  tipo_participantes get_tipo() { return tipo; };               // consultora  
  int get_pv() { return puntos_vitales; };
  void set_pv( int pv = 0 );
  void set_posicion( int p );
  int get_posicion();
  void disminuir_pv( int pv = 1 );
  void aumentar_pv( int pv = 1 );
  void dibujar( SDL_Surface *pantalla );
  void dibujar_pv();
  void dibujar_pv( int x, int y, int width, int height );

  virtual void actualizar() = 0;
  virtual void colisiona_con( Participante *otro ) = 0;


    // Vector con los rectángulos que forman el personaje
    vector<SDL_Rect> rectangulos;

 protected:

  void add_rect(SDL_Rect rect){ rectangulos.push_back( rect ); }

  bool mover_sobre_x( int incremento );                  // controla el movimiento horizontal
  bool pisa_el_suelo();                                  // comprueba si se pisa el suelo
  bool pisa_el_suelo( int _x, int _y );                  // comprueba si se pisa el suelo
  int altura( int rango );                               // calcula altura

  Imagen *imagen;
  Juego *juego;
  int x, y;
  int direccion;
  int posicion;
  float velocidad_salto;
  int puntos_vitales;
  enum estados estado;
  enum estados estado_anterior;
  enum tipo_participantes tipo;

  map<estados, Secuencia *> animaciones;
};

#endif
