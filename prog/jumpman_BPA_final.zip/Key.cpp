// Listado: Key.cpp
// Implementación de la clase Key
#include <iostream>

#include "Key.h"
#include "Juego.h"
#include "Control_Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Key::Key( enum tipo_participantes tipo, Juego *juego, 
		  int x, int y, int direccion ) :
  Enemigo( juego, x, y, direccion, tipo ) {
  // según el tipo de enemigo que estemos creando
  if( tipo == TIPO_KEY ){
    imagen = juego->universo->galeria->get_imagen( Galeria::KEY );
    // creamos las animaciones para el personaje en particular
    animaciones[APPEAR] = new Secuencia( "0,1", 15 );
    animaciones[PARADO] = new Secuencia( "0,1", 15 );
    animaciones[MORIR] = new Secuencia( "2,3,4", 20 );

    SDL_Rect rect_principal[] = { { 35, 60, 13, 30 } };
    for(int i = 0; i < 1; i++)
	add_rect(rect_principal[i]);
  } else
    cerr << "Key::Key() -> Enemigo no contenplado" << endl;

  // estado inicial para los enemigos
  estado = APPEAR;

#ifdef DEBUG
  cout << "Key::Key()" << endl;
#endif
}

Key::~Key(){
#ifdef DEBUG    
    cout << "Key::~Key" << endl;
#endif
}

void Key::actualizar(){
  switch( estado ) {

  case MORIR: 
    // cuando la secuencia alcance el final se cambia de estado
    if( animaciones[ estado ]->avanzar() )
      estado = ELIMINAR;
    break;

  case ELIMINAR: break;

  case PARADO:
    animaciones[ estado ]->avanzar();
    break;

  case APPEAR :
    if( pisa_el_suelo() ){ estado = PARADO; break; }
    animaciones[ estado ]->avanzar();

    // si llega al limite vertical muere
    if( y > NIV_HEIGHT ) estado = ELIMINAR;

    // tiene que llegar al suelo
    if( !pisa_el_suelo() ){
      velocidad_salto += 0.1;
      y += altura( (int) velocidad_salto );
      mover_sobre_x( direccion );
    }
    break;

  default: break;
  }
}
