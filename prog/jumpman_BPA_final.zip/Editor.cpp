// Listado: Editor.cpp
// Implementación de la clase Editor
#include <iostream>

#include "Editor.h"
#include "Universo.h"
#include "Nivel.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Teclado.h"
#include "Apuntador.h"
#include "Fuente.h"
#include "Musica.h"
#include "Common_Const.h"

using namespace std;

Editor::Editor( Universo *universo ) : Interfaz( universo ) {
  // inicializamos los atributos de la clase
  nivel = new  Nivel( universo, 0, FILAS_ZONA_EDITABLE, COLUMNAS_ZONA_EDITABLE );

  // acciones de teclado en el editor
  teclado = &( universo->teclado ); 

  // apuntador del ratón para el editor
  apuntador = new Apuntador( this );

  x = y = barra_scroll_ = capa = 0;
  ED_BG_COLOR = SDL_MapRGB( universo->pantalla->format, ED_BG_R, ED_BG_G, ED_BG_B );

  // imagen con los tiles para el editor
  imagen = universo->galeria->get_imagen( Galeria::TILES_ED );
  imagen_ch = universo->galeria->get_imagen( Galeria::TILES_CH );
  imagen_bk = universo->galeria->get_imagen( Galeria::TILES_BK );
  imagen_tl = universo->galeria->get_imagen( Galeria::TILES );

#ifdef DEBUG
  cout << "Editor::Editor()" << endl;
#endif
}

Editor::~Editor(){
  delete nivel;
  delete apuntador;

#ifdef DEBUG
  cout << "Editor::~Editor()" << endl;
#endif
}

void Editor::reiniciar(){ 
  // hacemos sonar la música
  universo->galeria->get_musica( Galeria::MUSICA_EDITOR )->pausar();   
  universo->galeria->get_musica( Galeria::MUSICA_EDITOR )->reproducir();

  // cargamos el nivel actual de juego
  int indice = universo->modificar_nivel();
  nivel->set_nivel( indice );
}

void Editor::actualizar(){
  // mueve la ventana a la posición correspondiente
  mover_ventana();

  // actualiza los elementos del Editor
  nivel->actualizar();

  // actualiza la posición del puntero del ratón
  apuntador->actualizar();

  // si se pulsa la tecla de salida se vuelve al menú
  if( teclado->pulso( EXIT ) )
    universo->set_interfaz( ESCENA_MENU );
}

void Editor::mover_barra_scroll( int desplazamiento ){
  // incrementamos la posición de la barra
  barra_scroll_ += desplazamiento;

  // dentro de los parámetros permitidos
  if( barra_scroll_ < 0 ) barra_scroll_ = 0;
  if( barra_scroll_ > ED_MAX_FIL  ) barra_scroll_ = ED_MAX_FIL;
}

int Editor::barra_scroll() { return barra_scroll_; }

void Editor::set_capa( int desplazamiento ){
  static int change = capa;

  // incrementamos la posición de la capa
  capa += desplazamiento;

  // dentro de los parámetros permitidos
  if( capa < 0 ) capa = 0;
  if( capa > 2  ) capa = 2;

  if( capa != change ){
    change = capa;
    barra_scroll_ = 0;
    apuntador->reset_bloque();
  }
}

int Editor::get_capa() { return capa; }

void Editor::mover_ventana(){
  int x0 = x;
  int y0 = y;

  /* según la pulsación de la tecla movemos la ventana de la aplicación
     en un sentido un otro */
  if( teclado->pulso( LEFT ) ) x -= 20;
  else if( teclado->pulso( RIGHT ) ) x += 20;
  else if( teclado->pulso( DOWN ) ) y += 20;
  else if( teclado->pulso( UP ) ) y -= 20;

  // si existe movimiento
  if( x != x0 || y != y0 ){
    nivel->ventana->set_destino( x, y );
    nivel->ventana->get_destino( &x, &y );
  }
}

void Editor::dibujar(){
  // dibuja todos los elementos del editor
  nivel->dibujar_bloques( universo->pantalla );
  nivel->dibujar_actores( universo->pantalla );

  // mostramos el menú
  dibujar_menu();

  apuntador->dibujar( universo->pantalla );  // mostramos el puntero del ratón
  dibujar_numero_nivel();                    // mostramos el número del nivel actual

  // actualizamos la pantalla 
  SDL_Flip( universo->pantalla );
}

void Editor::dibujar_menu(){
  // color de fondo para zona de menu
  //  universo->dibujar_rect( ED_X + 16, 0, TAM_BLOQUE * 7, + TAM_BLOQUE * 4, ED_BG_COLOR );

  // para regresar al menu, recargar nivel y guardar cambios
  imagen->dibujar( universo->pantalla, 14, ED_X + TAM_BLOQUE, 0 );
  imagen->dibujar( universo->pantalla, 13, ED_X + TAM_BLOQUE * 2 , 0 );
  imagen->dibujar( universo->pantalla, 12, ED_X + TAM_BLOQUE * 2, 32 );

  // para borrar nivel y borrar capas
  imagen->dibujar( universo->pantalla, 11, ED_X + TAM_BLOQUE * 4, 0 );
  imagen->dibujar( universo->pantalla, 10, ED_X + TAM_BLOQUE * 5, 0 );
  imagen->dibujar( universo->pantalla, 9, ED_X + TAM_BLOQUE * 4, 32 );
  imagen->dibujar( universo->pantalla, 8, ED_X + TAM_BLOQUE * 5, 32 );

  // flechas para el scrolling, desplazamiento entre capas y nivel 
  imagen->dibujar( universo->pantalla, 6, ED_X + TAM_BLOQUE, 96 );
  imagen->dibujar( universo->pantalla, 7, ED_X + TAM_BLOQUE * 2, 96 );
  imagen->dibujar( universo->pantalla, 4, ED_X + TAM_BLOQUE * 3, 96 );
  imagen->dibujar( universo->pantalla, 5, ED_X + TAM_BLOQUE * 4, 96 );
  imagen->dibujar( universo->pantalla, 2, ED_X + TAM_BLOQUE * 5, 96 );
  imagen->dibujar( universo->pantalla, 3, ED_X + TAM_BLOQUE * 6, 96 );

  // elementos
  switch( capa ){

  case 0:
    for( int i = 0; i < 10; i ++ ){
      for( int j = 0; j < ED_COLUMN; j ++ ){
        imagen_tl->dibujar( universo->pantalla,
  		          ( i + barra_scroll_ ) * ED_COLUMN + j,
  		          ED_X + j * TAM_BLOQUE, 
  		          ( 3 * TAM_BLOQUE ) + TAM_BLOQUE + i * TAM_BLOQUE);
      }
    } break;

  case 1:
    for( int i = 0; i < 10; i ++ ){
      for( int j = 0; j < ED_COLUMN; j ++ ){
        imagen_bk->dibujar( universo->pantalla,
  		          ( i + barra_scroll_ ) * ED_COLUMN + j,
  		          ED_X + j * TAM_BLOQUE, 
  		          ( 3 * TAM_BLOQUE ) + TAM_BLOQUE + i * TAM_BLOQUE);
      }
    } break;

  case 2:
    for( int i = 0; i < 10; i ++ ){
      for( int j = 0; j < ED_COLUMN; j ++ ){
        imagen_ch->dibujar( universo->pantalla,
  		          ( i + barra_scroll_ ) * ED_COLUMN + j,
  		          ED_X + j * TAM_BLOQUE, 
  		          ( 3 * TAM_BLOQUE ) + TAM_BLOQUE + i * TAM_BLOQUE);
      }
    } break;
  } // fin switch( capa )

  dibujar_separador();
}

void Editor::dibujar_separador(){
static Uint32 color = SDL_MapRGB( universo->pantalla->format, 193, 205, 193 );

  // dinujamos las diviciones horizontales
  for( int i = 1; i < 10; i++ )
    universo->dibujar_rect( ED_X, ( 4 + i ) * TAM_BLOQUE, ED_WIDTH, 2, color );
  
  // dibujamos las diviciones verticales
  for( int i = 1; i < ED_COLUMN; i++ )
    universo->dibujar_rect( ED_X + i * TAM_BLOQUE, 4 * TAM_BLOQUE, 2, 10 * 32, color );
}

void Editor::dibujar_numero_nivel(){
  char titulo[ 20 ];

  Fuente *fuente = universo->galeria->get_fuente( Galeria::FUENTE_MENU );
  sprintf( titulo, "N IV E L - %d", nivel->get_index() );
  fuente->palabra( universo->pantalla, titulo, 10, 10 );
}
