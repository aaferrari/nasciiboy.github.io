// Listado: Enemigo.cpp
// Implementación de la clase Enemigo
#include <iostream>

#include "Enemigo.h"
#include "Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Enemigo::Enemigo( Juego *juego, int x, int y, int direccion,
                  enum tipo_participantes tipo ) :
  Participante( juego, x, y, direccion ) {
  this->tipo = tipo;
#ifdef DEBUG
  cout << "Enemigo::Enemigo()" << endl;
#endif
}

Enemigo::~Enemigo(){
  map<estados, Secuencia *>::iterator p = animaciones.begin();
  while ( p != animaciones.end() ){
    delete p->second;
#ifdef DEBUG
    cout << "Enemigo delete estado: " << p->first << endl;
#endif
    p++;
  }

#ifdef DEBUG    
    cout << "Enemigo::~Enemigo" << endl;
#endif
}

void Enemigo::colisiona_con( Participante *otro ){
  /* si colisiona y el personaje principal está golpeando
     muere para desaparecer */
  if( estado != MORIR ){
    juego->universo->galeria->sonidos[ Galeria::MATA_MALO ]->reproducir();

    estado = MORIR;
  }
}
