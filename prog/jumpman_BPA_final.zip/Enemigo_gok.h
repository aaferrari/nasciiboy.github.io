// Listado: Enemigo_gok.h
/* Clase Enemigo_gok, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef ENEMIGO_GOK_H
#define ENEMIGO_GOK_H

#include "Enemigo.h"

class Juego;

class Enemigo_gok : public Enemigo {
 public:
  Enemigo_gok( enum tipo_participantes tipo, Juego *juego,
	       int x, int y, int direccion = 1 );
  virtual ~Enemigo_gok();

  virtual void actualizar();
};

#endif
