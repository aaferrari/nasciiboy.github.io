// Listado: Fire.cpp
// Implementación de la clase Fire
#include <iostream>

#include "Fire.h"
#include "Juego.h"
#include "Control_Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Fire::Fire( enum tipo_participantes tipo, Juego *juego, 
            int x, int y, int direccion ) :
  Enemigo( juego, x, y, direccion, tipo ) {
  // según el tipo de enemigo que estemos creando
  if( tipo == TIPO_FIRE_LOK ){
    imagen = juego->universo->galeria->get_imagen( Galeria::FIRE_LOK );
    // creamos las animaciones para el personaje en particular
    animaciones[GOLPEAR] = new Secuencia( "0,1,2", 5 );
    animaciones[MORIR] = new Secuencia( "4,5,6", 2 );

    SDL_Rect rect_principal[] = { { 5, 5, 10, 10 } };
    for(int i = 0; i < 1; i++)
	add_rect(rect_principal[i]);
  } else
    cerr << "Fire::Fire() -> Enemigo no contenplado" << endl;

  // estado inicial para los enemigos
  estado = GOLPEAR;

#ifndef DEBUG
  cout << "Fire::Fire()" << endl;
#endif
}

Fire::~Fire(){
#ifdef DEBUG    
    cout << "Fire::~Fire" << endl;
#endif
}

void Fire::actualizar(){
  switch( estado ) {

  case MORIR: 
    x += direccion * 2;

    // cuando la secuencia alcance el final se cambia de estado
    if( animaciones[ estado ]->avanzar() )
      estado = ELIMINAR;
    break;

  case ELIMINAR: break;

  case GOLPEAR:
    animaciones[ estado ]->avanzar();
    x += direccion * 2;

    if( x > NIV_WIDTH + 10 ) estado = MORIR;
    if( x < -10 ) estado = MORIR;
    if( y > NIV_HEIGHT + 10 ) estado = MORIR;
    if( y < -10 ) estado = MORIR;
    break;

  default: break;
  }
}
