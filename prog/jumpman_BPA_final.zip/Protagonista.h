// Listado: Protagonista.h
// Esta clase controla los distintos aspectos del proyagonista
#ifndef _PROTAGONISTA_H
#define _PROTAGONISTA_H

#include <SDL/SDL.h>

#include "Participante.h"

class Juego;
class Participante;
class Teclado;

class Protagonista: public Participante {
 public:
  Protagonista( Juego *juego, int x, int y, int direccion = 1 ); // constructor
  ~Protagonista();                                               // destructor  

  void actualizar();
  void colisiona_con( Participante *otro );

 private:
  Teclado *teclado;  // dispositivo que controla el personaje
  int x0, y0, super; 
  void reiniciar();

  // estados del protagonista para la implementación del autómata
  void state_appear();
  void estado_caminar();
  void estado_parado();
  void estado_super();
  void estado_disparar();
  void estado_saltar();
  void estado_morir();
  void state_damage();
};

#endif
