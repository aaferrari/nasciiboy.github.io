// Listado: Musica.cpp
// Implementación de la clase Música
#include <iostream>

#include "Musica.h"
#include "Common_Const.h"

using namespace std;

Musica::Musica( const char *path ){
  bso = Mix_LoadMUS( path );  // cargamos la música
  if( bso == NULL ){
    cerr << "Música no disponible" << Mix_GetError() << endl;
    exit( 1 );
  }

  // establecemos un volumen predeterminado
  Mix_VolumeMusic( MUSIC_VOL );

#ifdef DEBUG
  cout << "Música cargada" << endl;
#endif
}

Musica::~Musica(){
  Mix_FreeMusic( bso ); 

#ifdef DEBUG
  cout << "Musica::~Musica" << endl;
#endif
}

void Musica::reproducir() { Mix_PlayMusic( bso, -1 ); }

void Musica::pausar(){ Mix_PauseMusic(); }
