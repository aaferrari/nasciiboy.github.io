// Librería auxiliar para evitar tareas repetitivas de inicializacion y salida de SDL
#ifndef _SD_INITL_H
#define _SD_INITL_H

#include <SDL/SDL.h>

#include "Common_Const.h"

// Inicializa SDL con los parámetros predeterminados
int sdl_init( SDL_Surface **pantalla, SDL_Surface **icon,  const char *caption = WM_CAPTION, \
              int ancho = WM_WIDTH, int alto = WM_HEIGHT, int bpp = WM_BPP );

// Maneja los eventos de salida
int close_event( SDL_Surface **pantalla, SDL_Surface **icon );

#endif
