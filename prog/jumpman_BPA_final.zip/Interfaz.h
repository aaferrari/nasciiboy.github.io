// Listado: Interfaz.h 
// Superclase de las diferentes escenas disponibles en la aplicación
#ifndef INTERFAZ_H
#define INTERFAZ_H

class Universo;

class Interfaz {
 public:
  Interfaz( Universo *universo );  // constructor
  virtual ~Interfaz();	           // destructor

  // tres son las escenas que encontramos en la aplicación
  enum escenas { ESCENA_INTRO, ESCENA_END, ESCENA_MENU, ESCENA_JUEGO, ESCENA_EDITOR };

  // funciones virtuales puras comunes a todas las escenas
  virtual void reiniciar() = 0;
  virtual void dibujar() = 0;
  virtual void actualizar() = 0;

  Universo *universo;
};

#endif
