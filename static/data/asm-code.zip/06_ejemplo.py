def multadd(x, y, a):
    res = x*y + a
    return res

r1 = multadd(5, 3, 2)
r2 = multadd(2, 4, 1)
