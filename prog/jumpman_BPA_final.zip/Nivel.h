// Listado: Nivel.h
/* Esta clase controla todo lo relevante a la construcción
   de los nivel del juego */
#ifndef NIVEL_H
#define NIVEL_H

#include <SDL/SDL.h>

#include "Ventana.h"
#include "Common_Const.h"

class Ventana;
class Imagen;
class Universo;
class Control_Juego;

struct Datos { 
  float num_nivel;
  unsigned char tiles[ BQ_NIVEL_HEIGHT ][ BQ_NIVEL_WIDTH ];
  unsigned char characters[ BQ_NIVEL_HEIGHT ][ BQ_NIVEL_WIDTH ];
  unsigned char block[ BQ_NIVEL_HEIGHT ][ BQ_NIVEL_WIDTH ];
};

class Nivel {
 public:
  Nivel( Universo *universo, int index = 0,
	 int filas = NIV_DEFAULT_FILAS, int columnas = NIV_DEFAULT_COLUMMNAS );
  ~Nivel();                                        // destructor

  void actualizar();                               // actualizando el nivel
  void dibujar_bloques( SDL_Surface *superficie ); // funcion de dibujo
  void dibujar_actores( SDL_Surface *superficie ); // funcion de dibujo
  void get_actores( Control_Juego *procesos );     // genera los actores 
  int altura( int x, int y, int rango );           // actualizando el nivel
  int altura( int x, int y );                      // actualizando el nivel
  bool no_es_traspasable( int codigo );            // comprueba si el elemento es traspasable
  bool set_nivel( int s_n = 0 );                   // para establecer el nivel
  int siguiente();                                 // pasa al nivel siguiente o al anterior
  void anterior();                                 // pasa al nivel siguiente o al anterior
  void editar_bloque( int capa, int i, int x, int y );   // funcion para la edición del nivel
  void guardar();                                  // funcion para la edición del nivel
  int cargar();                                    // funcion para la edición del nivel
  void limpiar( int capa = 4 );                    // funcion para la edición del nivel
  int get_index();                                 // devuelve el número de nivel
  Ventana *ventana;                                // foco de la acción

 private:
  int numero_nivel;
  int filas, columnas;
  bool modificado;                             // indica si este nivel ha sido editado
  Datos nivel;                                 // almacena las características del nivel
  FILE *fichero;                               // para guardar el nivel
  Imagen *tl, *bk;                             // almacena los tiles
  SDL_Surface *fondo;                          // almacena la imagen de fondo
  Universo *universo;

  void abrir_fichero();                        // funcion para el manejo de ficheros
  void cerrar_fichero();                       // funcion para el manejo de ficheros
  FILE *crear_fichero( const char *name );     // funcion para nuevos ficheros
  void copiar_fichero( FILE *tmp );            // funcion para el manejo de ficheros
};

#endif 
