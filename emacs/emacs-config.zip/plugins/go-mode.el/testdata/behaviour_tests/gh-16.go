package magiccomma

/*
extern void CallMyFunction(void* pfoo);
*/
import "C"
