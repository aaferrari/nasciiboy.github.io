// Listado: Enemigo_aok.cpp
// Implementación de la clase Enemigo_aok
#include <iostream>

#include "Enemigo_aok.h"
#include "Juego.h"
#include "Control_Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Secuencia.h"
#include "Nivel.h"

using namespace std;

Enemigo_aok::Enemigo_aok( enum tipo_participantes tipo, Juego *juego, 
                          int x, int y, int direccion ) :
  Enemigo( juego, x, y, direccion, tipo ) {
  // según el tipo de enemigo que estemos creando
  if( tipo == TIPO_ENEMIGO_AOK ){
    imagen = juego->universo->galeria->get_imagen( Galeria::ENEMIGO_AOK );
    // creamos las animaciones para el personaje en particular
    animaciones[FLY] = new Secuencia( "0" , 5 );
    animaciones[GOLPEAR] = new Secuencia( "0,1,2", 50 );
    animaciones[MORIR] = new Secuencia( "3,4", 10 );

    SDL_Rect rect_principal[] = { { 40, 90, 12,  8 },
                                  { 25, 22, 50, 28 }, 
                                  { 35, 50, 30, 15 },
                                  { 32, 80, 28, 10 }, };
    for( int i = 0; i < 1; i++ )
      add_rect( rect_principal[ i ] );
  } else
    cerr << "Enemigo_aok::Enemigo_aok() -> Enemigo no contenplado" << endl;

  // estado inicial para los enemigos
  estado = FLY;

#ifdef DEBUG
  cout << "Enemigo_aok::Enemigo_aok()" << endl;
#endif
}

Enemigo_aok::~Enemigo_aok(){
#ifdef DEBUG    
    cout << "Enemigo_aok::~Enemigo_aok" << endl;
#endif
}

void Enemigo_aok::actualizar(){
  switch( estado ) {

  case MORIR: 
    // cuando la secuencia alcance el final se cambia de estado
    if( animaciones[ estado ]->avanzar() )
      estado = ELIMINAR;
    break;

  case ELIMINAR: break;

  case FLY:
    if( posicion != 0 ) estado = GOLPEAR;
    if( !mover_sobre_x( direccion ) ) direccion *= -1;
    break;

  case GOLPEAR:
    if( animaciones[ estado ]->avanzar() ){
      int x_ = ( direccion == 1 ) ? x + 65 : x - 75; 
      juego->control_juego->get_enemigo( Participante::TIPO_ENEMIGO_BOK,
					 x_, y - 0, direccion );
    }
    if( posicion == 0 ) estado = FLY;

    if( posicion  < 0 ) { direccion = 1; mover_sobre_x( direccion * 2 ); }
    else if( posicion == 1 ) { direccion = -1; mover_sobre_x( direccion * 2 ); }
    else if( posicion == 2 );
    break;

  default: break;
  }
}
