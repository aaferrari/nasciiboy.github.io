// Listado: Menu.h
// Esta clase controla los aspectos relevantes al Menú de la aplicación
#ifndef MENU_H
#define MENU_H

#include <SDL/SDL.h>

#include "Interfaz.h"
#include "Common_Const.h"

class Control_Movimiento;
class Imagen;
class Secuencia;
class Teclado;
class Texto;

class Menu: public Interfaz {
 public:
  Menu( Universo *universo );  // constructor
  ~Menu();                     // destructor

  // funciones heradas de Interfaz operativa de la clase
  void reiniciar ();
  void actualizar ();
  void dibujar ();

 private:
  Control_Movimiento *cursor;  // para indicador de opccion
  Imagen *inbo;
  Secuencia *secuencia;

  void get_strings();          // crea las cadenas que se almacenarán en cadena_opciones

  int opcion;                  // almacena la opccion a la que apunta el cursor
  bool panel_visible;          // para controlar si se muestra el panel de opciones
  Uint32 MN_BG_COLOR;          // color de fondo para el menu
  Teclado *teclado;            // controla el dispositivo de entrada
  Texto *opciones[ NUM_OPCIONES ];  // frases que componen el menú
};

#endif
