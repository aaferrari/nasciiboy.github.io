// Listado: Sonido.h
// Clase para facilitar el trabajo con sonidos
#ifndef _SONIDO_H
#define _SONIDO_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

class Sonido {
 public:
  Sonido( const char *path );  // constructor
  ~Sonido();                   // desstructor

  void reproducir();

 private:
  Mix_Chunk *sonido;
};

#endif
