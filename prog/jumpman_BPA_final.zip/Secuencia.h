// Listado: Secuencia.h
// Esta clase controla la secuencia de una animacion
#ifndef _SECUENCIA_H
#define _SECUENCIA_H

#include <vector>

using namespace std;

class Secuencia {
 public:
  Secuencia( const char *frames, int retardo = 0 );   // constructor
  ~Secuencia();                                       // destructor
void test();
  void set_frame( int nf );       // establece el frame especificado
  int get_frame();                // consulta frame actual
  int get_size();                 // consulta el numero de frames en la secuencia 
  bool inicio();                  // consulta si es el frame 0
  bool fin();                     // consula si es el frame final
  bool fin( int nf );             // consula si es el final del frame
  int avanzar();                  // avanza en siguiente frame de la secuencia
  void reiniciar();               // reinicia la secuencia al frame cero

 private:
  int 
    paso,                         // almacena el paso actual de la secuencia
    delay,                        // establece el retardo entre cuadros de animacion
    cont_delay;                   // contador para llevar un control del retardo

  vector<int> cuadros;            // almacena los cuadros que componen la animacion

  int validar( int nf = 0 );      // para validaar si el frame se encuentra en el vector
};

#endif
