// Listado: Enemigo_aok.h
/* Clase Enemigo_aok, heredada de Participante, para el control
   de los adversarios del juego */
#ifndef ENEMIGO_AOK_H
#define ENEMIGO_AOK_H

#include "Enemigo.h"

class Juego;

class Enemigo_aok : public Enemigo {
 public:
  Enemigo_aok( enum tipo_participantes tipo, Juego *juego,
	       int x, int y, int direccion = 1 );
  virtual ~Enemigo_aok();

  virtual void actualizar();
};

#endif
