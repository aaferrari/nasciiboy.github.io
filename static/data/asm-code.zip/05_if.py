X = 1
Y = 1
Z = 0

if (X == Y):
        Z = X + Y
