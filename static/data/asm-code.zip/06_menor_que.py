def nummenorque(vector_s, dim_s, dato_s):
      n = 0
      for i in range(dim_s):
           if vector_s[i] < dato_s:
              n = n + 1;
      return n

vector = [5, 3, 5, 5, 8, 12, 12, 15, 12]
dim = 9
num = 12
res1 = nummenorque(vector, dim, num + 1)
res2 = nummenorque(vector, dim, num)
res = res1 - res2
