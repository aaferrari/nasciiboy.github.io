// Listado: Control_Juego.cpp
// Implementación de la clase Control_Juego
#include <iostream>
#include <cstdlib>
#include <cstring>

#include "Control_Juego.h"
#include "Juego.h"
#include "Colision.h"
#include "Item.h"
#include "Participante.h"
#include "Enemigo.h"
#include "Enemigo_dok_rok.h"
#include "Enemigo_aok.h"
#include "Enemigo_bok.h"
#include "Enemigo_fok.h"
#include "Enemigo_gok.h"
#include "Enemigo_lok.h"
#include "Fire.h"
#include "Key.h"
#include "Protagonista.h"
#include "Universo.h"
#include "Galeria.h"
#include "Fuente.h"
#include "Secuencia.h"

using namespace std;

Control_Juego::Control_Juego( Juego *juego ): protagonista_( NULL ) {
  this->juego = juego;
  fuente = juego->universo->galeria->get_fuente( Galeria::FUENTE_MARCADOR );
  puntos = 0;
  marcador_bg = SDL_MapRGB( juego->universo->pantalla->format,
			    NVM_BG_R, NVM_BG_G, NVM_BG_B );
  protagonista_ = NULL;
  
#ifdef DEBUG
  cout << "Control_Juego::Control_Juego()" << endl;
#endif
}

Control_Juego::~Control_Juego(){
  kill_all();

#ifdef DEBUG
  cout << "Control_Juego::~Control_Juego()" << endl;
#endif
}

void Control_Juego::actualizar(){
  // actualizamos el protagonista
  if( protagonista_ )
    protagonista_->actualizar();

  // actualizamos todos los enemigos    
  for( list<Key *>::iterator i = lista_keys.begin();
       i != lista_keys.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los enemigos    
  for( list<Enemigo_dok_rok *>::iterator i = lista_enemigos_dok_rok.begin();
       i != lista_enemigos_dok_rok.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los enemigos aok
  for( list<Enemigo_aok *>::iterator i = lista_enemigos_aok.begin();
       i != lista_enemigos_aok.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los enemigos bok
  for( list<Enemigo_bok *>::iterator i = lista_enemigos_bok.begin();
       i != lista_enemigos_bok.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los enemigos fok
  for( list<Enemigo_fok *>::iterator i = lista_enemigos_fok.begin();
       i != lista_enemigos_fok.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los enemigos gok
  for( list<Enemigo_gok *>::iterator i = lista_enemigos_gok.begin();
       i != lista_enemigos_gok.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los enemigos lok
  for( list<Enemigo_lok *>::iterator i = lista_enemigos_lok.begin();
       i != lista_enemigos_lok.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los items
  for( list<Item *>::iterator i = lista_items.begin();
       i != lista_items.end(); i++ )
    (*i)->actualizar();

  // actualizamos todos los fires
  for( list<Fire *>::iterator i = lista_fires.begin();
       i != lista_fires.end(); i++ )
    (*i)->actualizar();

  // eliminamos los marcados con ELIMINAR
  eliminar_antiguos_enemigos_dok_rok( lista_enemigos_dok_rok );
  eliminar_antiguos_enemigos_aok( lista_enemigos_aok );
  eliminar_antiguos_enemigos_bok( lista_enemigos_bok );
  eliminar_antiguos_enemigos_fok( lista_enemigos_fok );
  eliminar_antiguos_enemigos_gok( lista_enemigos_gok );
  eliminar_antiguos_enemigos_lok( lista_enemigos_lok );
  eliminar_antiguos_items( lista_items );
  eliminar_antiguos_keys( lista_keys );
  eliminar_antiguos_fires( lista_fires );

  // estudiamos las posibles colisiones
  if( protagonista_ != NULL ) avisar_colisiones();
}

void Control_Juego::dibujar( SDL_Surface *pantalla ){
  // dibujamos toda la lista de items
  for( list<Item *>::iterator i = lista_items.begin();
       i != lista_items.end(); i++ )
    (*i)->dibujar(juego->universo->pantalla);

  // dibujamos al protagonista
  if( protagonista_ ){
    protagonista_->dibujar( juego->universo->pantalla );
    protagonista_->dibujar_pv( 10, 50, 22, 100 );
  }

  // dibujamos toda la lista de enemigos
  for( list<Enemigo_dok_rok *>::iterator i = lista_enemigos_dok_rok.begin();
       i != lista_enemigos_dok_rok.end(); i++ )
    (*i)->dibujar( juego->universo->pantalla );

  // dibujamos toda la lista de enemigos_ aok
  for( list<Enemigo_aok *>::iterator i = lista_enemigos_aok.begin();
       i != lista_enemigos_aok.end(); i++ )
    (*i)->dibujar( juego->universo->pantalla );

  // dibujamos toda la lista de enemigos_ bok
  for( list<Enemigo_bok *>::iterator i = lista_enemigos_bok.begin();
       i != lista_enemigos_bok.end(); i++ )
    (*i)->dibujar( juego->universo->pantalla );

  // dibujamos toda la lista de enemigos_ fok
  for( list<Enemigo_fok *>::iterator i = lista_enemigos_fok.begin();
       i != lista_enemigos_fok.end(); i++ )
    (*i)->dibujar( juego->universo->pantalla );

  // dibujamos toda la lista de enemigos_ gok
  for( list<Enemigo_gok *>::iterator i = lista_enemigos_gok.begin();
       i != lista_enemigos_gok.end(); i++ )
    (*i)->dibujar( juego->universo->pantalla );

  // dibujamos toda la lista de enemigos_ lok
  for( list<Enemigo_lok *>::iterator i = lista_enemigos_lok.begin();
       i != lista_enemigos_lok.end(); i++ )
    (*i)->dibujar( juego->universo->pantalla );

  // dibujamos los proyectiles
  for( list<Fire *>::iterator i = lista_fires.begin();
       i != lista_fires.end(); i++ )
    (*i)->dibujar(juego->universo->pantalla);

  // dibujamos toda la lista de keys
  for( list<Key *>::iterator i = lista_keys.begin();
       i != lista_keys.end(); i++ )
    (*i)->dibujar(juego->universo->pantalla);

  //  dibujar_marcador(); //  descomentar par ver un marcador
}

void Control_Juego::dibujar_marcador(){
  static char life[30] = "", ppa[ MAX_PV + 1 ] = "";
  unsigned int cont = 0;
  int i = 0;

  if( puntos != lista_enemigos_dok_rok.size() ){
    puntos = lista_enemigos_dok_rok.size();

    for( ; cont < puntos; cont++ )
      life[ cont ] = '#';
    life[ cont ] = '\0';
  }
  if( life[ 0 ] == '\0' )
    strcpy( life, " " );

  for( ; i < protagonista_->get_pv(); i++ )
    ppa[ i ] = '@';
  ppa[ i ] = '\0';

  if( ppa[ 0 ] == '\0' )
    strcpy( ppa, " " );

  juego->universo->dibujar_rect( 0, 0, WM_WIDTH, 30, marcador_bg );
  fuente->palabra( juego->universo->pantalla, life, 50, 0, NV_FONT_BG );
  fuente->palabra( juego->universo->pantalla, ppa, 500, 0, NV_FONT_BG );
}

void Control_Juego::avisar_colisiones(){
  int x0, y0;
  int x1, y1;

  // tomamos la posición del protagonista
  x0 = protagonista_->get_x();
  y0 = protagonista_->get_y();

  // tomamos posicion de enemigos y enviamos evaluamos con funcion
  for( list<Enemigo_dok_rok *>::iterator i = lista_enemigos_dok_rok.begin();
       i != lista_enemigos_dok_rok.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del enemigo

    hay_colision( x0, y0, x1, y1, (*i )  );
  }

  // tomamos posicion de  enemigos aok
  for( list<Enemigo_aok *>::iterator i = lista_enemigos_aok.begin();
       i != lista_enemigos_aok.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del enemigo

    hay_colision( x0, y0, x1, y1, (*i )  );
  }

  // tomamos posicion de enemigos bok
  for( list<Enemigo_bok *>::iterator i = lista_enemigos_bok.begin();
       i != lista_enemigos_bok.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del enemigo

    hay_colision( x0, y0, x1, y1, (*i )  );
  }

  // tomamos posicion de enemigos fok
  for( list<Enemigo_fok *>::iterator i = lista_enemigos_fok.begin();
       i != lista_enemigos_fok.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del enemigo

    hay_colision( x0, y0, x1, y1, (*i )  );
  }

  // tomamos posicion de enemigos gok
  for( list<Enemigo_gok *>::iterator i = lista_enemigos_gok.begin();
       i != lista_enemigos_gok.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del enemigo

    hay_colision( x0, y0, x1, y1, (*i ), 400  );
  }

  // tomamos posicion de enemigos lok
  for( list<Enemigo_lok *>::iterator i = lista_enemigos_lok.begin();
       i != lista_enemigos_lok.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del enemigo

    hay_colision( x0, y0, x1, y1, (*i )  );
  }

  // tomamos posicion de fires
  for( list<Fire *>::iterator i = lista_fires.begin();
       i != lista_fires.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del fire

    hay_colision( x0, y0, x1, y1, (*i )  );
  }

  // tomamos posicion de keys
  for( list<Key *>::iterator i = lista_keys.begin();
       i != lista_keys.end(); i++ ){
    x1 = (*i)->get_x(); y1 = (*i)->get_y();      // posición del fire

    hay_colision( x0, y0, x1, y1, (*i )  );
  }

  // tomamos posicion de objetos
  for( list<Item *>::iterator i = lista_items.begin();
	 i != lista_items.end(); i++ ){
    x1 = (*i)->get_x();      // posición del item
    y1 = (*i)->get_y();      // posición del item
	
    hay_colision( x0, y0, x1, y1, (*i ) );
  }
}

/* evaliamos las posiciones de los objetos
   radioactive # es el area para evaluacion */
void Control_Juego::hay_colision( int x0, int y0, int x1,
				  int y1, Enemigo *i, int radioactive ){
  if( ( abs( x0 - x1 ) < radioactive ) && ( abs( y0 - y1 ) < radioactive  ) ){
    /* si se encuentra dentro del rango radioactive se 
       compruevan los "rectangulos" individuales */
    if( colision( protagonista_, i ) ){
      // si protagonisata no se encuentra en estado de atake-> muere
      if( ( protagonista_->get_estado() != Participante::SUPER ) 
            && ( protagonista_->get_estado() != Participante::GOLPEAR ) ){
	// mata al protagonista
	protagonista_->colisiona_con( i ); 
      } else
	// muere el malo y es eliminado
	i->colisiona_con( protagonista_ );
      return;
    }
    /* establecemos datos acerca de la posicion con respecto al proganonista
       1 ò 2 # el protagonista se encuentra detras
       -1 ò -2 # el protagonista se encuentra delante */
    else {
      switch( i->get_tipo() ) {

      case Participante::TIPO_FIRE_LOK:
        if( x0 > x1 && ( abs( x0 - x1 ) > 20 ) ) i->set_posicion( -1 );
        else if( x0 < x1 && ( abs( x0 - x1 ) > 20 ) ) i->set_posicion( 1 );
        return;
      break;

      case Participante::TIPO_ENEMIGO_BOK:
        if( x0 > x1 ) i->set_posicion( -1 );
        else i->set_posicion( 1 );
        return;
      break;

      case Participante::TIPO_ENEMIGO_AOK:
        if( ( abs( x0 - x1 ) < 20 ) ) i->set_posicion( 2 );
        else if( x0 > x1 ) i->set_posicion( -1 );
        else if( x0 < x1 ) i->set_posicion( 1 );
        return;
      break;

      case Participante::TIPO_ENEMIGO_DOK:
        if( x0 > x1 && ( abs(y0 - y1) < 50 ) )	i->set_posicion( -1 );
        else if( x0 < x1 && ( abs(y0 - y1) < 50 ) ) i->set_posicion( 1 );
        else if( x0 > x1 ) i->set_posicion( -2 );
        else i->set_posicion( 2 );
        return;
      break;

      case Participante::TIPO_ENEMIGO_FOK:
        if( ( abs( x0 - x1 ) < 20 ) ) i->set_posicion( 2 );
        else if( x0 > x1 ) i->set_posicion( -1 );
        else if( x0 < x1 ) i->set_posicion( 1 );
        return;
      break;

      case Participante::TIPO_ENEMIGO_GOK:
        if( ( abs( x0 - x1 ) < 70 ) && ( abs(y1 - y0) < 70 ) &&  x0 > x1 ) 
	  i->set_posicion( -1 );
        else if( ( abs( x0 - x1 ) < 50 ) && ( abs(y0 - y1) < 70 ) && x0 < x1 )
	  i->set_posicion( 1 );
        else if( x0 > x1 && ( abs(y0 - y1) < 80 ) ) i->set_posicion( -2 );
        else if( x0 < x1 && ( abs(y0 - y1) < 80 ) ) i->set_posicion( 2 );
	else i->set_posicion( 0 );
        return;
      break;

      case Participante::TIPO_ENEMIGO_LOK:
        if( x0 > x1 && ( abs(y0 - y1) < 50 ) )	i->set_posicion( -1 );
        else if( x0 < x1 && ( abs(y0 - y1) < 50 ) ) i->set_posicion( 1 );
	else i->set_posicion( 0 );
        return;
      break;

      case Participante::TIPO_ENEMIGO_ROK:
        if( x0 > x1 && ( abs(y0 - y1) < 50 ) )	i->set_posicion( -1 );
        else if( x0 < x1 && ( abs(y0 - y1) < 50 ) ) i->set_posicion( 1 );
        else if( x0 > x1 ) i->set_posicion( -2 );
        else i->set_posicion( 2 );
        return;
      break;

      case Participante::TIPO_KEY: break;

      default: 
        cerr << "Control_Juego::hay_colision() ERR : caso no contemplado" << endl;
        break;
      }
    }
  }

  i->set_posicion( 0 );
}

bool Control_Juego::hay_colision( int x0, int y0, int x1, int y1, Item *i ){
  if( ( abs( x0 - x1 ) < ( RADIOACTIVE * 2 ) ) && ( abs( y0 - y1 ) < ( RADIOACTIVE *2 ) ) ){
    if( ( abs( x0 - x1 ) < ( RADIO_COLISION * 2 ) ) 
         && ( abs( y0 - y1 ) < ( RADIO_COLISION *2 ) ) ){
      if( i->get_estado() != Participante::MORIR && i->get_estado() != Participante::ELIMINAR ){
        switch( i->get_tipo() ){

        case Participante::TIPO_ITEM_POWER: protagonista_->aumentar_pv(); break;
        case Participante::TIPO_ITEM_LIFE: protagonista_->aumentar_pv( i->pv_life() ); break;
        default: break;
        }
      }

      i->colisiona_con( protagonista_ ); // elimina el ítem

      return true;
    }
    else {
      if( x0 > x1 && y0 == y1 )
        i->set_posicion( -1 );
      else i->set_posicion( 1 );
      return false;
    }
  }

  i->set_posicion( 0 );
  return false;
}

void Control_Juego::eliminar_antiguos_items( list<Item *>& lista ){
  list<Item *>::iterator i;
  bool eliminado = false;
  
  // Eliminamos los items marcados como eliminar
  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;         // devolvemos la memoria
      lista.erase(i);    // eliminamos elemento
      eliminado = true;  // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_keys( list<Key *>& lista ){
  list<Key *>::iterator i;
  bool eliminado = false;
  
  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;         // devolvemos la memoria
      lista.erase(i);    // eliminamos elemento
      eliminado = true;  // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_fires( list<Fire *>& lista ){
  list<Fire *>::iterator i;
  bool eliminado = false;
  
  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;         // devolvemos la memoria
      lista.erase(i);    // eliminamos elemento
      eliminado = true;  // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_enemigos_dok_rok( list<Enemigo_dok_rok *>& lista ){
  list<Enemigo_dok_rok *>::iterator i;
  bool eliminado = false;

  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;          // devolvemos la memoria
      lista.erase(i);     // eliminamos elemento
      eliminado = true;   // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_enemigos_aok( list<Enemigo_aok *>& lista ){
  list<Enemigo_aok *>::iterator i;
  bool eliminado = false;

  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;          // devolvemos la memoria
      lista.erase(i);     // eliminamos elemento
      eliminado = true;   // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_enemigos_bok( list<Enemigo_bok *>& lista ){
  list<Enemigo_bok *>::iterator i;
  bool eliminado = false;

  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;          // devolvemos la memoria
      lista.erase(i);     // eliminamos elemento
      eliminado = true;   // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_enemigos_fok( list<Enemigo_fok *>& lista ){
  list<Enemigo_fok *>::iterator i;
  bool eliminado = false;

  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;          // devolvemos la memoria
      lista.erase(i);     // eliminamos elemento
      eliminado = true;   // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_enemigos_gok( list<Enemigo_gok *>& lista ){
  list<Enemigo_gok *>::iterator i;
  bool eliminado = false;

  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;          // devolvemos la memoria
      lista.erase(i);     // eliminamos elemento
      eliminado = true;   // evita recorrer toda la lista
    }
  }
}

void Control_Juego::eliminar_antiguos_enemigos_lok( list<Enemigo_lok *>& lista ){
  list<Enemigo_lok *>::iterator i;
  bool eliminado = false;

  for( i = lista.begin(); i != lista.end() && eliminado == false; i++ ){
    if( (*i)->get_estado() == Participante::ELIMINAR ){
      delete *i;          // devolvemos la memoria
      lista.erase(i);     // eliminamos elemento
      eliminado = true;   // evita recorrer toda la lista
    }
  }
}

void Control_Juego::get_enemigo( Participante::tipo_participantes tipo,
				 int x, int y, int flip ){
#ifdef DEBUG    
  cout << "Creando un enemigo tipo " << tipo << " en ( " << x << " - "
       << y << " )" << endl;
#endif

  // almacenamos en las listas el tipo enemigo que queremos crear
  switch( tipo ) {

  case Participante::TIPO_KEY:
    lista_keys.push_back( new Key( Participante::TIPO_KEY,
				   juego, x, y, flip ) );
    break;

  case Participante::TIPO_FIRE_LOK:
    lista_fires.push_back( new Fire( Participante::TIPO_FIRE_LOK,
				     juego, x, y, flip ) );
    break;

  case Participante::TIPO_ENEMIGO_AOK:
    lista_enemigos_aok.push_back( new Enemigo_aok( Participante::TIPO_ENEMIGO_AOK,
			  		           juego, x, y, flip ) );
    break;

  case Participante::TIPO_ENEMIGO_BOK:
    lista_enemigos_bok.push_back( new Enemigo_bok( Participante::TIPO_ENEMIGO_BOK,
			  		           juego, x, y, flip ) );
    break;

  case Participante::TIPO_ENEMIGO_DOK:
    lista_enemigos_dok_rok.push_back( new Enemigo_dok_rok( Participante::TIPO_ENEMIGO_DOK,
							   juego, x, y, flip ) );
    break;

  case Participante::TIPO_ENEMIGO_FOK:
    lista_enemigos_fok.push_back( new Enemigo_fok( Participante::TIPO_ENEMIGO_FOK,
			  		           juego, x, y, flip ) );
    break;

  case Participante::TIPO_ENEMIGO_GOK:
    lista_enemigos_gok.push_back( new Enemigo_gok( Participante::TIPO_ENEMIGO_GOK,
			  		           juego, x, y, flip ) );
    break;

  case Participante::TIPO_ENEMIGO_LOK:
    lista_enemigos_lok.push_back( new Enemigo_lok( Participante::TIPO_ENEMIGO_LOK,
			  		           juego, x, y, flip ) );
    break;

  case Participante::TIPO_ENEMIGO_ROK:
    lista_enemigos_dok_rok.push_back( new Enemigo_dok_rok( Participante::TIPO_ENEMIGO_ROK,
							   juego, x, y, flip ) );
    break;
	 
  default: cerr << "Get Enemigo: Enemigo desconocido" << endl; break;
  }
}

void Control_Juego::get_protagonista( int x, int y, int flip ){
  if( protagonista_ == NULL )
    protagonista_ = new Protagonista( juego, x, y, flip );
  else
    cerr << "Ya existe un protagonista en el nivel" << endl;
}

void Control_Juego::get_item( Participante::tipo_participantes tipo,
			      int x, int y, int flip ){
#ifdef DEBUG
  cout << "Creando un item en ( " << x << " - "
       << y << " )" << endl;
#endif   

  // almacenamos en las listas el tipo de item que queremos crear
  switch( tipo ){

  case Participante::TIPO_ITEM_POWER:
    lista_items.push_back( new Item( Participante::TIPO_ITEM_POWER,
				     juego, x, y, flip ) );
    break;

  case Participante::TIPO_ITEM_LIFE:
    lista_items.push_back( new Item( Participante::TIPO_ITEM_LIFE,
				     juego, x, y, flip ) );
    break;
	 
  default:
    cerr << "Get Item: Item desconocido" << endl; break;
  }
}


void Control_Juego::kill_all(){ 
  // borramos las estructuras activas del juego
  if( protagonista_ != NULL ){  
    delete protagonista_;
    protagonista_ = NULL;
#ifdef DEBUG
    cout << "\n============== PROTAGONISTA ELIMINADO ==============" << endl;
#endif

  }

  if( !lista_enemigos_dok_rok.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR ENEMIGOS DOK-ROK elementos #"
	 << lista_enemigos_dok_rok.size() << " ==============" << endl;
#endif

    for( list<Enemigo_dok_rok *>::iterator i = lista_enemigos_dok_rok.begin();
	 i != lista_enemigos_dok_rok.end(); i++ ){
      delete *i;
    }
    lista_enemigos_dok_rok.clear();    // eliminamos elementos 
#ifdef DEBUG
    cout << "============== ENEMIGOS DOK-ROK ELIMINADOS sobrevivientes #"
	 << lista_enemigos_dok_rok.size() << " ==============" << endl;
#endif

  }

  if( !lista_enemigos_aok.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR ENEMIGOS AOK elementos #"
	 << lista_enemigos_aok.size() << " ==============" << endl;
#endif

    for( list<Enemigo_aok *>::iterator i = lista_enemigos_aok.begin();
	 i != lista_enemigos_aok.end(); i++ ){
      delete *i;
    }
    lista_enemigos_aok.clear();    // eliminamos elementos 
#ifdef DEBUG
    cout << "============== ENEMIGOS AOK ELIMINADOS sobrevivientes #"
	 << lista_enemigos_aok.size() << " ==============" << endl;
#endif
  }

  if( !lista_enemigos_bok.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR ENEMIGOS BOK elementos #"
	 << lista_enemigos_bok.size() << " ==============" << endl;
#endif

    for( list<Enemigo_bok *>::iterator i = lista_enemigos_bok.begin();
	 i != lista_enemigos_bok.end(); i++ ){
      delete *i;
    }
    lista_enemigos_bok.clear();    // eliminamos elementos 
#ifdef DEBUG
    cout << "============== ENEMIGOS BOK ELIMINADOS sobrevivientes #"
	 << lista_enemigos_bok.size() << " ==============" << endl;
#endif
  }

  if( !lista_enemigos_fok.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR ENEMIGOS FOK elementos #"
	 << lista_enemigos_fok.size() << " ==============" << endl;
#endif

    for( list<Enemigo_fok *>::iterator i = lista_enemigos_fok.begin();
	 i != lista_enemigos_fok.end(); i++ ){
      delete *i;
    }
    lista_enemigos_fok.clear();    // eliminamos elementos 
#ifdef DEBUG
    cout << "============== ENEMIGOS FOK ELIMINADOS sobrevivientes #"
	 << lista_enemigos_fok.size() << " ==============" << endl;
#endif
  }

  if( !lista_enemigos_gok.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR ENEMIGOS GOK elementos #"
	 << lista_enemigos_gok.size() << " ==============" << endl;
#endif

    for( list<Enemigo_gok *>::iterator i = lista_enemigos_gok.begin();
	 i != lista_enemigos_gok.end(); i++ ){
      delete *i;
    }
    lista_enemigos_gok.clear();    // eliminamos elementos 
#ifdef DEBUG
    cout << "============== ENEMIGOS GOK ELIMINADOS sobrevivientes #"
	 << lista_enemigos_gok.size() << " ==============" << endl;
#endif
  }

  if( !lista_enemigos_lok.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR ENEMIGOS LOK elementos #"
	 << lista_enemigos_lok.size() << " ==============" << endl;
#endif

    for( list<Enemigo_lok *>::iterator i = lista_enemigos_lok.begin();
	 i != lista_enemigos_lok.end(); i++ ){
      delete *i;
    }
    lista_enemigos_lok.clear();    // eliminamos elementos 
#ifdef DEBUG
    cout << "============== ENEMIGOS LOK ELIMINADOS sobrevivientes #"
	 << lista_enemigos_lok.size() << " ==============" << endl;
#endif
  }

  if( !lista_items.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR ITEMS elementos #"
	 << lista_items.size() << " ==============" << endl;
#endif

    for( list<Item *>::iterator i = lista_items.begin();
	 i != lista_items.end(); i++ ){
      delete *i;
    }
    lista_items.clear();      // eliminamos elemento
#ifdef DEBUG
    cout << "============== ITEMS ELIMINADOS sobrevivientes #"
	 << lista_items.size() << " ==============" << endl;
#endif
  }

  if( !lista_fires.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR FIRES elementos #"
	 << lista_fires.size() << " ==============" << endl;
#endif

    for( list<Fire *>::iterator i = lista_fires.begin();
	 i != lista_fires.end(); i++ ){
      delete *i;
    }
    lista_fires.clear();      // eliminamos elemento
#ifdef DEBUG
    cout << "============== FIRES ELIMINADOS sobrevivientes #"
	 << lista_fires.size() << " ==============" << endl;
#endif
  }

  if( !lista_keys.empty() ){
#ifdef DEBUG
    cout << "\n============== ELIMINAR KEYS elementos #"
	 << lista_keys.size() << " ==============" << endl;
#endif

    for( list<Key *>::iterator i = lista_keys.begin();
	 i != lista_keys.end(); i++ ){
      delete *i;
    }
    lista_keys.clear();      // eliminamos elemento
#ifdef DEBUG
    cout << "============== KEYS ELIMINADOS sobrevivientes #"
	 << lista_keys.size() << " ==============" << endl;
#endif
  }

}

// para informar sobre si hay llaves faltantes por encontrar
bool Control_Juego::kill(){
  if( lista_keys.empty() )
    return true;
  else
    return false;
}

// para obtener los puntos vitales del protagonista
int Control_Juego::get_hero() { return protagonista_->get_pv(); }

// para establecer los puntos vitales del protagonista
void Control_Juego::set_hero( int pv ) { protagonista_->set_pv( pv ); }
